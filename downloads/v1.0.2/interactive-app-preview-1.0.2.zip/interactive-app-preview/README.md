# Interactive App Preview — 1.0.2 public review candidate

Publisher: Ali Mohammad (علي محمد).
**Status: offline pre-submission candidate only. Not uploaded, approved or published.**

Guides interactive app prototypes based on the supplied project source, including original colors, layout, typography, icons, RTL and navigation. Includes offline theme extraction and preview audit scripts. A preview is not a compiled APK, native emulator result, or live backend; payment and account data must be synthetic by default.

This skills-only plugin includes no MCP server, publisher-operated telemetry, login or payment processing. It may instruct ChatGPT to use separate authorized user-connected tools when available; those services have their own access, data-processing and license terms.

Project input files may be processed by ChatGPT or tools authorized by the user. Bundled offline scripts run in an available execution environment and do not automatically upload data to a publisher server; optional locally saved reports remain in that environment. Do not provide real private keys, production logs or customer data for public support.

Homepage: https://hamoshi90.github.io/tools/interactive-app-preview/
Privacy: https://hamoshi90.github.io/tools/interactive-app-preview/privacy/
Terms: https://hamoshi90.github.io/tools/interactive-app-preview/terms/
Support: https://hamoshi90.github.io/support/

License: Apache-2.0 for material the publisher has authority to license. Third-party SDKs and commands are not included simply by reference. See LICENSE and NOTICE.

Before any distribution: confirm intellectual-property ownership and applicable rights, check publisher identity, review privacy and terms, and pass official upload and policy scans.
