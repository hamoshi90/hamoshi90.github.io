"""Offline regression tests for design-source evidence and safe preview validation."""
import hashlib
import json
import sys
import tempfile
import unittest
from pathlib import Path

SKILL = Path(__file__).resolve().parents[1] / 'skills' / 'interactive-app-preview'
sys.path.insert(0, str(SKILL / 'scripts'))

import theme_probe
import audit_preview


class PreviewToolTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)

    def write(self, rel, text):
        path = self.root / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding='utf-8')
        return path

    def scan(self):
        return theme_probe.scan_project(self.root)

    def test_css_custom_properties_are_source_grounded(self):
        f = self.write('assets/styles.css', ':root{--navy:#102a3c; --green: #18b58f; --bg:#f5f8f8}')
        manifest = self.scan()
        tokens = {t['name']:t for t in manifest['tokens']}
        self.assertEqual(tokens['navy']['value'], '#102a3c')
        self.assertEqual(tokens['green']['value'], '#18b58f')
        self.assertEqual(tokens['green']['source'], 'assets/styles.css')
        self.assertEqual(tokens['green']['source_sha256'], hashlib.sha256(f.read_bytes()).hexdigest())
        self.assertEqual(manifest['evidence_level'], 'source-extracted-not-render-verified')

    def test_android_colors_xml_resolves_named_values(self):
        self.write('app/src/main/res/values/colors.xml', '<resources><color name="primary">#FF102A3C</color><color name="accent">#18b58f</color></resources>')
        vals = {(t['name'], t['value']) for t in self.scan()['tokens']}
        self.assertIn(('primary', '#102a3c'), vals)
        self.assertIn(('accent', '#18b58f'), vals)

    def test_android_night_theme_stays_distinct(self):
        self.write('app/src/main/res/values/colors.xml', '<resources><color name="surface">#ffffff</color></resources>')
        self.write('app/src/main/res/values-night/colors.xml', '<resources><color name="surface">#000000</color></resources>')
        vals = [t for t in self.scan()['tokens'] if t['name']=='surface']
        self.assertEqual(len(vals),2)
        self.assertEqual({t['mode'] for t in vals}, {'light-or-default', 'dark'})

    def test_compose_color_declarations(self):
        self.write('ui/theme/Color.kt', 'package demo\nval Mint = Color(0xFF18B58F)\nval Navy = Color(0xFF102A3C)')
        vals = {t['name']:t['value'] for t in self.scan()['tokens']}
        self.assertEqual(vals['Mint'],'#18b58f')
        self.assertEqual(vals['Navy'],'#102a3c')

    def test_flutter_dart_theme(self):
        self.write('lib/theme/app_theme.dart', 'final primaryColor = const Color(0xff147f67);')
        vals = {t['name']:t['value'] for t in self.scan()['tokens']}
        self.assertEqual(vals['primaryColor'], '#147f67')

    def test_react_native_theme_and_json(self):
        self.write('src/theme/colors.ts', 'export const colors = { primary: "#178766", surface: "#f5f8f8" }')
        self.write('src/design-tokens.json', '{"secondary": "#aabbcc"}')
        vals = {(t['name'], t['value']) for t in self.scan()['tokens']}
        self.assertIn(('primary','#178766'),vals)
        self.assertIn(('secondary','#aabbcc'),vals)

    def test_missing_source_cannot_be_called_exact(self):
        self.write('README.md','Demo has a beautiful blue theme')
        manifest = self.scan()
        self.assertEqual(manifest['tokens'], [])
        self.assertEqual(manifest['evidence_level'], 'missing-design-evidence')

    def test_css_export_does_not_invent_roles(self):
        self.write('styles.css', ':root {--brand:#AABBCC; --surface:#ffffff}')
        output = theme_probe.render_css(self.scan())
        self.assertIn('--source-brand: #aabbcc;',output)
        self.assertIn('--source-surface: #ffffff;',output)
        self.assertNotIn('primary',output)

    def test_audit_exact_stylesheet_hash_does_not_claim_android_runtime(self):
        stylesheet = self.write('styles.css', ':root{--brand:#aabbcc}')
        html = self.write('preview.html', '<html dir="rtl"><style>:root{--brand:#aabbcc}</style><button>إرسال</button></html>')
        manifest = self.scan()
        # Source-stylesheet identity only, not native UI equivalence.
        result = audit_preview.audit(manifest, html, stylesheet, source_stylesheet=stylesheet, rtl=True, offline=True)
        self.assertTrue(result['passed'])
        self.assertEqual(result['stylesheet_fidelity'], 'source-stylesheet-identical')
        self.assertEqual(result['runtime_verified'], False)

    def test_audit_distinguishes_reimplementation_from_exact_css(self):
        self.write('styles.css', ':root{--brand:#aabbcc}')
        html = self.write('preview.html', '<html dir="rtl"><button>Start</button></html>')
        css = self.write('preview.css', 'button{background:#aabbcc}')
        r = audit_preview.audit(self.scan(),html,css,rtl=True,offline=True)
        self.assertTrue(r['passed'])
        self.assertEqual(r['stylesheet_fidelity'], 'color-overlap-only')

    def test_audit_fails_when_preview_uses_wrong_palette(self):
        self.write('styles.css',':root{--brand:#aabbcc}')
        html=self.write('preview.html','<html dir="rtl"></html>')
        css=self.write('preview.css','body{background:#123456}')
        r=audit_preview.audit(self.scan(),html,css,rtl=True,offline=True)
        self.assertFalse(r['passed'])
        self.assertIn('No source palette colors', ' '.join(r['issues']))

    def test_audit_fails_when_financial_preview_calls_backend(self):
        self.write('styles.css',':root{--brand:#aabbcc}')
        html=self.write('preview.html','<html dir="rtl"><script>fetch("https://example.org/send")</script></html>')
        css=self.write('preview.css','body{background:#aabbcc}')
        r=audit_preview.audit(self.scan(),html,css,rtl=True,offline=True)
        self.assertFalse(r['passed'])
        self.assertIn('Network-capable code detected', ' '.join(r['issues']))

    def test_rtl_required_must_be_explicit(self):
        self.write('styles.css',':root{--brand:#aabbcc}')
        html=self.write('preview.html','<html><button>Send</button></html>')
        css=self.write('preview.css','body{color:#aabbcc}')
        r=audit_preview.audit(self.scan(),html,css,rtl=True,offline=True)
        self.assertFalse(r['passed'])
        self.assertIn('RTL', ' '.join(r['issues']))

    def test_scan_does_not_modify_original_sources(self):
        f=self.write('styles.css',':root{--brand:#aabbcc}')
        before=f.read_bytes()
        self.scan()
        self.assertEqual(f.read_bytes(),before)


if __name__ == '__main__':
    unittest.main()
