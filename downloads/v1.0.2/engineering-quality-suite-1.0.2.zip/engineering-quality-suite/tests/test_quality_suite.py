"""Standard-library tests for all five independent offline review tools."""
import copy
import hashlib
import importlib.util
import json
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FILES = {
    "finance": "financial-transaction-safety/scripts/financial_audit.py",
    "api": "api-integration-tester/scripts/api_contract_check.py",
    "release": "production-release-gatekeeper/scripts/release_gate.py",
    "android": "android-ui-regression-qa/scripts/android_regression_check.py",
    "database": "database-integrity-migration/scripts/sqlite_readonly_check.py",
}


def load(name):
    path = ROOT / "skills" / FILES[name]
    spec = importlib.util.spec_from_file_location("eqs_" + name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


FINANCE = load("finance")
API = load("api")
RELEASE = load("release")
ANDROID = load("android")
DATABASE = load("database")

TRANSFER = {"idempotency_key": "a-private-operation-key", "events": [
    {"status": "created"}, {"status": "previewed"}, {"status": "submitted"},
    {"status": "pending"}, {"status": "succeeded"}],
    "send_attempts": 1, "receipt_verified": True, "debited": True}
API_CASE = {"cases": [{"actual": {"http_status": 200, "body": {"result": 1206, "succeeded": False,
      "payload": {"message": "synthetic"}}}, "expect": {"http_status": 200,
      "fields": {"result": 1206, "succeeded": False}, "required_paths": ["payload.message"]}}]}
RELEASE_DATA = {"approved_baseline": "R1", "candidate_version": "R1-test", "target": "staging",
    "live_finance": False, "checks": {k: True for k in RELEASE.BASE}, "approvals": {}}
ANDROID_DATA = {"application_id": "org.example.clientb", "expected_application_id": "org.example.clientb",
    "version_code": 2, "previous_version_code": 1, "min_sdk": 24, "device_api": 35,
    "build_variant": "debug", "required_scenarios": ["cold_launch", "mock_send"],
    "scenarios": {"cold_launch": {"passed": True, "evidence": "CI-cold-launch"},
        "mock_send": {"passed": True, "evidence": "QA-synthetic-send"}},
    "signature_check": {"passed": True, "method": "apksigner", "evidence": "CI-apksigner-log"}}


class TestFinance(unittest.TestCase):
    def test_synthetic_happy_path(self):
        self.assertEqual(FINANCE.audit({"transfers": [TRANSFER]})["status"], "pass")

    def test_duplicate_idempotency_key(self):
        r = FINANCE.audit({"transfers": [TRANSFER, TRANSFER]})
        self.assertIn("IDEMPOTENCY_KEY_REUSED_ACROSS_OPERATIONS", [x["code"] for x in r["findings"]])

    def test_unknown_outcome_and_resend(self):
        t = copy.deepcopy(TRANSFER)
        t["events"][-1]["status"] = "unknown"
        t["send_attempts"] = 2
        codes = [x["code"] for x in FINANCE.audit({"transfers": [t]})["findings"]]
        self.assertIn("AMBIGUOUS_OUTCOME_WITH_RESEND", codes)
        self.assertIn("UNRESOLVED_OUTCOME_NO_AUTORETRY", codes)

    def test_rejected_with_debit_blocks(self):
        t = copy.deepcopy(TRANSFER)
        t["events"][-1]["status"] = "rejected"
        codes = [x["code"] for x in FINANCE.audit({"transfers": [t]})["findings"]]
        self.assertIn("DECLINED_BUT_DEBIT_REPORTED", codes)

    def test_illegal_state_transition(self):
        t = copy.deepcopy(TRANSFER)
        t["events"] = [{"status": "created"}, {"status": "succeeded"}]
        self.assertEqual(FINANCE.audit({"transfers": [t]})["status"], "block")

    def test_no_credential_leak_in_report(self):
        r = FINANCE.audit({"transfers": [TRANSFER, TRANSFER]})
        self.assertNotIn("a-private-operation-key", json.dumps(r))

    def test_missing_status_and_invalid_input(self):
        self.assertEqual(FINANCE.audit({"transfers": [{"idempotency_key": "xx"}]})["status"], "block")
        with self.assertRaises(ValueError):
            FINANCE.audit({})


class TestApi(unittest.TestCase):
    def test_expected_contract(self):
        self.assertEqual(API.audit(API_CASE)["status"], "pass")

    def test_http_failure(self):
        t = copy.deepcopy(API_CASE)
        t["cases"][0]["actual"]["http_status"] = 500
        self.assertIn("HTTP_STATUS_MISMATCH", [x["code"] for x in API.audit(t)["findings"]])

    def test_boolean_does_not_equal_integer(self):
        t = copy.deepcopy(API_CASE)
        t["cases"][0]["actual"]["body"]["succeeded"] = 0
        self.assertIn("EXPECTED_FIELD_MISMATCH", [x["code"] for x in API.audit(t)["findings"]])

    def test_path_absent(self):
        t = copy.deepcopy(API_CASE)
        t["cases"][0]["actual"]["body"].pop("payload")
        self.assertIn("REQUIRED_PATH_ABSENT", [x["code"] for x in API.audit(t)["findings"]])

    def test_invalid_case(self):
        self.assertEqual(API.audit({"cases": [None]})["status"], "fail")
        with self.assertRaises(ValueError):
            API.audit({})

    def test_sensitive_value_hidden(self):
        t = copy.deepcopy(API_CASE)
        t["cases"][0]["actual"]["body"]["payload"]["message"] = "secret-that-should-not-show"
        t["cases"][0]["expect"]["fields"]["payload.message"] = "different"
        self.assertNotIn("secret-that-should-not-show", json.dumps(API.audit(t)))


class TestRelease(unittest.TestCase):
    def test_staging_checklist_complete(self):
        self.assertEqual(RELEASE.audit(RELEASE_DATA)["status"], "checklist_pass")

    def test_missing_evidence_blocks(self):
        t = copy.deepcopy(RELEASE_DATA)
        t["checks"]["security_reviewed"] = False
        self.assertEqual(RELEASE.audit(t)["status"], "blocked")

    def test_production_needs_more_evidence(self):
        t = copy.deepcopy(RELEASE_DATA)
        t["target"] = "production"
        self.assertEqual(RELEASE.audit(t)["status"], "blocked")

    def test_baseline_change_requires_approval(self):
        t = copy.deepcopy(RELEASE_DATA)
        t["target"] = "production"
        t["checks"].update({k: True for k in RELEASE.PRODUCTION})
        self.assertIn("BASELINE_CHANGE_NOT_APPROVED", RELEASE.audit(t)["blockers"])
        t["approvals"]["baseline_change_approved"] = True
        self.assertEqual(RELEASE.audit(t)["status"], "checklist_pass")

    def test_financial_live_requires_distinct_approval(self):
        t = copy.deepcopy(RELEASE_DATA)
        t["target"] = "production"
        t["live_finance"] = True
        t["checks"].update({k: True for k in RELEASE.PRODUCTION + RELEASE.FINANCIAL})
        t["approvals"]["baseline_change_approved"] = True
        self.assertIn("LIVE_FINANCE_NOT_APPROVED", RELEASE.audit(t)["blockers"])
        t["approvals"]["live_finance_approved"] = True
        self.assertEqual(RELEASE.audit(t)["status"], "checklist_pass")

    def test_missing_financial_mode_blocks(self):
        t = copy.deepcopy(RELEASE_DATA)
        del t["live_finance"]
        self.assertEqual(RELEASE.audit(t)["status"], "blocked")


class TestAndroid(unittest.TestCase):
    def test_complete_attestations(self):
        self.assertEqual(ANDROID.audit(ANDROID_DATA)["status"], "attestations_complete")

    def test_package_mismatch(self):
        t = copy.deepcopy(ANDROID_DATA)
        t["application_id"] = "org.other.app"
        self.assertIn("APPLICATION_ID_CHANGED", ANDROID.audit(t)["issues"])

    def test_upgrade_code_must_increase(self):
        t = copy.deepcopy(ANDROID_DATA)
        t["version_code"] = t["previous_version_code"]
        self.assertIn("UPGRADE_VERSION_CODE_NOT_INCREASED", ANDROID.audit(t)["issues"])

    def test_device_too_old(self):
        t = copy.deepcopy(ANDROID_DATA)
        t["min_sdk"] = 36
        self.assertIn("DEVICE_API_BELOW_MIN_SDK", ANDROID.audit(t)["issues"])

    def test_missing_scenario_evidence(self):
        t = copy.deepcopy(ANDROID_DATA)
        t["scenarios"]["mock_send"]["evidence"] = ""
        self.assertIn("SCENARIO_EVIDENCE_MISSING", ANDROID.audit(t)["issues"])

    def test_crypto_attestation_not_provided(self):
        t = copy.deepcopy(ANDROID_DATA)
        t["signature_check"]["method"] = "guess"
        self.assertIn("SIGNATURE_ATTESTATION_MISSING", ANDROID.audit(t)["issues"])

    def test_invalid_manifest_input(self):
        with self.assertRaises(ValueError):
            ANDROID.audit(None)


class TestDatabase(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / "test.sqlite"
        with sqlite3.connect(self.path) as db:
            db.execute("CREATE TABLE users (id INTEGER PRIMARY KEY)")
            db.execute("INSERT INTO users VALUES(1)")
            db.execute("CREATE TABLE tx(id INTEGER PRIMARY KEY, user_id INTEGER REFERENCES users(id))")
            db.execute("INSERT INTO tx VALUES(1,1)")

    def test_read_only_pass_and_no_file_mutation(self):
        before = hashlib.sha256(self.path.read_bytes()).hexdigest()
        r = DATABASE.audit(self.path)
        after = hashlib.sha256(self.path.read_bytes()).hexdigest()
        self.assertEqual(r["status"], "pass")
        self.assertEqual(before, after)

    def test_fk_violation_detection(self):
        with sqlite3.connect(self.path) as db:
            db.execute("INSERT INTO tx VALUES(2,999)")
        r = DATABASE.audit(self.path)
        self.assertEqual(r["status"], "blocked")
        self.assertGreater(r["checks"]["foreign_key_violations"], 0)

    def test_corrupted_sqlite_error(self):
        self.path.write_bytes(b"not a sqlite database")
        with self.assertRaises(sqlite3.DatabaseError):
            DATABASE.audit(self.path)

    def test_missing_file(self):
        with self.assertRaises(ValueError):
            DATABASE.audit(self.path.with_name("does-not-exist.db"))

    def test_size_cap(self):
        with self.assertRaises(ValueError):
            DATABASE.audit(self.path, max_bytes=1)


class TestCli(unittest.TestCase):
    def test_all_scripts_fail_safely_on_invalid_json(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "bad.json"
            p.write_text("{invalid\n", encoding="utf-8")
            for name in ("finance", "api", "release", "android"):
                path = ROOT / "skills" / FILES[name]
                res = subprocess.run([sys.executable, str(path), str(p)], capture_output=True, text=True, timeout=5)
                self.assertEqual(res.returncode, 2, name)
                self.assertEqual(json.loads(res.stdout)["status"], "error")

    def test_database_cli(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "db.sqlite"
            sqlite3.connect(path).close()
            script = ROOT / "skills" / FILES["database"]
            res = subprocess.run([sys.executable, str(script), str(path)], capture_output=True, text=True, timeout=5)
            self.assertEqual(res.returncode, 0)
            self.assertEqual(json.loads(res.stdout)["status"], "pass")


if __name__ == "__main__":
    unittest.main()
