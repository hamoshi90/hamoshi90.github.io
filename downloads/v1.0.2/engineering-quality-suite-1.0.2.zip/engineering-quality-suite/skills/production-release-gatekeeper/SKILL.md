---
name: production-release-gatekeeper
description: Evaluate release readiness, approved baselines, CI test evidence, security review, dependencies, backup/restore, database migration, rollback procedures, monitoring, incident handling and explicit approvals. Use before staging or production deployments, publishing builds, changing live bot or Android releases, enabling real transfers, changing baseline or issuing a go/no-go decision on authorized apps.
---

# Production Release Gatekeeper

Provide an explicit, conservative go/no-go review. **The checklist tool cannot authorize deployment or independently verify evidence**; humans and actual test logs remain required.

## Procedure
1. Identify exact project, original archive SHA-256, approved baseline, candidate build, production/live status and deployment target. Never silently promote a development candidate to the baseline.
2. Preserve existing live deployments. Stage modifications in a distinct branch/artifact with reproducible versioning; enumerate database/schema versions and rollback compatibility.
3. Require actual unit/integration/security CI logs; review dependency and secret scanning, owner/tenant isolation, data backup/restore drills, rollback drills, migration dry-runs, observability and incident playbook.
4. For financial live operations require explicit separate approval, idempotency evidence, reconciliation tests and failure-injection results. A user's broad request for permissions in another project does not grant approval in the current project.
5. Prepare release manifest from independently examined artifacts; mark any unverified item false. Execute `python scripts/release_gate.py /path/to/release_manifest.json`; anything missing or false blocks.
6. Inspect scripted findings and supporting evidence, then declare `blocked` or `conditional` rather than claiming rollout is safe. Even `checklist_pass` is **self-reported** until independently validated.
7. Never deploy, publish, execute real transfers, alter credentials, or update an approved baseline without the current user's explicit authorization.

## Output
Summarize current baseline; proposed candidate; evidence list with provenance; blockers; separate staging vs production assessment; reversible deployment sequence; post-deploy monitoring and stop/rollback triggers.

See [Release manifest and rules](references/release-manifest.md).
