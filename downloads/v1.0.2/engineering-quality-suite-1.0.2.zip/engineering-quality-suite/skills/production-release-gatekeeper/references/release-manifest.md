# Release manifest and rules

Example **staging** manifest; `true` values are placeholders only, not evidence:

```json
{"approved_baseline":"0.4.0","candidate_version":"0.4.1-dev","target":"staging","live_finance":false,"checks":{"source_verified":true,"unit_tests_passed":true,"integration_tests_passed":true,"security_reviewed":true,"secrets_scanned":true,"dependency_reviewed":true},"approvals":{}}
```

Production additionally requires `backup_restore_tested`, `rollback_tested`, `migration_tested`, `monitoring_ready`, `incident_plan_ready`, `release_notes_reviewed`. Different candidate version from baseline requires `approvals.baseline_change_approved=true`. If `live_finance=true`, require separate `approvals.live_finance_approved=true` and `idempotency_tested`, `reconciliation_tested`, `provider_failure_cases_tested`.

- Run: `python scripts/release_gate.py /path/to/release_manifest.json`.
- Do not blindly set check values to `true`. Link each to actual artifact/log in the report. Treat any missing evidence as **blocked**.
- Program performs no deployment or update, never contacts GitHub or any payment provider.
