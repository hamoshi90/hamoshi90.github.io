#!/usr/bin/env python3
"""Fail-closed release checklist linter. Assertions are NOT independent evidence."""
import argparse
import json
from pathlib import Path

BASE = ("source_verified", "unit_tests_passed", "integration_tests_passed",
        "security_reviewed", "secrets_scanned", "dependency_reviewed")
PRODUCTION = ("backup_restore_tested", "rollback_tested", "migration_tested",
              "monitoring_ready", "incident_plan_ready", "release_notes_reviewed")
FINANCIAL = ("idempotency_tested", "reconciliation_tested", "provider_failure_cases_tested")


def audit(data):
    if not isinstance(data, dict):
        raise ValueError("Expected manifest object")
    checks = data.get("checks")
    approvals = data.get("approvals")
    if not isinstance(checks, dict) or not isinstance(approvals, dict):
        raise ValueError("Manifest needs checks and approvals objects")
    target = data.get("target")
    blockers = []
    if target not in ("staging", "production"):
        blockers.append("INVALID_TARGET")
    baseline = data.get("approved_baseline")
    candidate = data.get("candidate_version")
    if not isinstance(baseline, str) or not baseline.strip():
        blockers.append("MISSING_APPROVED_BASELINE")
    if not isinstance(candidate, str) or not candidate.strip():
        blockers.append("MISSING_CANDIDATE_VERSION")
    required = BASE + (PRODUCTION if target == "production" else ())
    for field in required:
        if checks.get(field) is not True:
            blockers.append("CHECK_MISSING_OR_FALSE:" + field)
    if target == "production" and baseline != candidate and approvals.get("baseline_change_approved") is not True:
        blockers.append("BASELINE_CHANGE_NOT_APPROVED")
    if data.get("live_finance") is True:
        if target != "production":
            blockers.append("LIVE_FINANCE_REQUIRES_PRODUCTION_REVIEW")
        for field in FINANCIAL:
            if checks.get(field) is not True:
                blockers.append("CHECK_MISSING_OR_FALSE:" + field)
        if approvals.get("live_finance_approved") is not True:
            blockers.append("LIVE_FINANCE_NOT_APPROVED")
    elif data.get("live_finance") is not False:
        blockers.append("LIVE_FINANCE_MODE_NOT_EXPLICIT")
    return {
        "status": "blocked" if blockers else "checklist_pass",
        "target": target,
        "blockers": blockers,
        "interpretation": "self_reported_checklist_only_not_deployment_authorization_or_test_evidence",
    }


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("manifest_json", type=Path)
    a = p.parse_args()
    try:
        if a.manifest_json.stat().st_size > 1_000_000:
            raise ValueError("Manifest exceeds 1 MB")
        r = audit(json.loads(a.manifest_json.read_text(encoding="utf-8")))
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(json.dumps({"status": "error", "error_type": type(exc).__name__}))
        return 2
    print(json.dumps(r, indent=2))
    return 0 if r["status"] == "checklist_pass" else 2


if __name__ == "__main__":
    raise SystemExit(main())
