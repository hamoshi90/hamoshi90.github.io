#!/usr/bin/env python3
"""Offline, redacted API fixture assertion runner. No HTTP requests are made."""
import argparse
import json
from pathlib import Path

_MISSING = object()


def resolve(data, dotted):
    current = data
    for name in dotted.split("."):
        if not isinstance(current, dict) or name not in current:
            return _MISSING
        current = current[name]
    return current


def audit(data):
    if not isinstance(data, dict) or not isinstance(data.get("cases"), list):
        raise ValueError("Expected cases list")
    findings = []

    def add(i, code):
        findings.append({"case_index": i, "code": code})

    for i, c in enumerate(data["cases"]):
        if not isinstance(c, dict) or not isinstance(c.get("actual"), dict) or not isinstance(c.get("expect"), dict):
            add(i, "INVALID_CASE")
            continue
        actual = c["actual"]
        expected = c["expect"]
        if "http_status" not in expected or type(expected["http_status"]) is not int:
            add(i, "EXPECTED_HTTP_STATUS_MISSING")
        elif actual.get("http_status") != expected["http_status"]:
            add(i, "HTTP_STATUS_MISMATCH")
        body = actual.get("body")
        if not isinstance(body, dict):
            add(i, "ACTUAL_BODY_NOT_OBJECT")
            continue
        fields = expected.get("fields", {})
        required = expected.get("required_paths", [])
        if not isinstance(fields, dict) or not isinstance(required, list):
            add(i, "INVALID_EXPECTATIONS")
            continue
        for path in required:
            if not isinstance(path, str) or not path or resolve(body, path) is _MISSING:
                add(i, "REQUIRED_PATH_ABSENT")
        for path, value in fields.items():
            if not isinstance(path, str) or not path or resolve(body, path) is _MISSING:
                add(i, "EXPECTED_FIELD_ABSENT")
            elif resolve(body, path) != value or type(resolve(body, path)) is not type(value):
                add(i, "EXPECTED_FIELD_MISMATCH")
    return {"status": "pass" if not findings else "fail", "cases": len(data["cases"]),
            "findings": findings, "scope": "offline_fixtures_no_network_or_credentials"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("fixture_json", type=Path)
    a = parser.parse_args()
    try:
        if a.fixture_json.stat().st_size > 5_000_000:
            raise ValueError("Fixture exceeds 5 MB")
        result = audit(json.loads(a.fixture_json.read_text(encoding="utf-8")))
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(json.dumps({"status": "error", "error_type": type(exc).__name__}))
        return 2
    print(json.dumps(result, indent=2))
    return 0 if result["status"] == "pass" else 2


if __name__ == "__main__":
    raise SystemExit(main())
