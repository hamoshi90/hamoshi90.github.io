# Contract fixture specification

Define one test per endpoint/scenario in JSON. `actual.http_status` is separate from `actual.body`. `expect.fields` checks exact values at dotted JSON paths. `required_paths` checks existence only. No network is used.

```json
{"cases":[{"name":"synthetic_login_invalid","endpoint":"/Authentication/signin","actual":{"http_status":200,"body":{"succeeded":false,"result":1206}},"expect":{"http_status":200,"fields":{"succeeded":false,"result":1206},"required_paths":["succeeded","result"]}}]}
```

- Mask real response data before adding it to cases. Do not include decrypted financial fields, payloads, secrets or identities.
- Run: `python scripts/api_contract_check.py /path/to/sanitized_cases.json`.
- Non-zero exit code means mismatches or invalid inputs. Script reports case indices and reason codes, not actual values.
- Supplement with framework-level integration tests against a disposable test DB; a fixture alone cannot prove runtime API behavior.
- Historical provider traffic may be incomplete or physically truncated; record uncertainty and avoid inventing missing content.
