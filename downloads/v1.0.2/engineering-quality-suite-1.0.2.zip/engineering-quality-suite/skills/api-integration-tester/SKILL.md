---
name: api-integration-tester
description: Validate service integrations and API contracts with sanitized offline fixtures, including authentication, email OTP, 2FA, wallet balances, pagination, transaction statuses, ownership, error responses and backward compatibility. Use for API changes, FastAPI endpoints, wallet-provider sandbox responses, route contracts, JSON schema drift, provider result codes or integration regressions. Test real endpoints only when explicitly permitted and restricted to authorized test systems.
---

# API Integration Tester

Validate API behavior from a contract and evidence, not assumptions about HTTP status. Pair with Context7 for framework documentation and Superpowers for test-driven fixes.

## Procedure
1. Identify project/baseline and enumerate each endpoint, contract version and caller. Preserve contract compatibility unless the user approves a versioned change.
2. Derive positive and negative scenarios: account not found, login and 2FA state, token expiry, owner isolation, validation errors, rate limits, balance, transfer confirmation, history, partial responses, retries, network disconnects, pagination, and malformed payloads.
3. Work from **sanitized expected/actual fixtures**. Do not store plaintext credentials, OTP codes, bearer tokens, session keys, request `encData`/AES keys, wallet IDs or private user data.
4. Generate `cases[]`, each with explicit `actual` and `expect` values. Run `python scripts/api_contract_check.py /path/to/cases.json`. The script is offline, does not call HTTP and compares only declared assertions.
5. Require endpoint-specific meaning for application codes (`succeeded`, `result`, etc.). HTTP 200 does not imply business success. Never assume application codes have uniform meaning across services.
6. For local FastAPI projects, use TestClient/dependency overrides with test databases; do not route tests to live financial providers or send real transfers. For external staging APIs, obtain explicit authorization before making calls.
7. Review schema evolution, pagination, idempotency, auth scope, logs, timeout semantics and response truncation; classify unobserved fields as unknown instead of inventing.
8. State precisely which tests ran, what fixture versions they used, which endpoint was emulated, and what needs an authorized live/staging test.

See [Contract fixture specification](references/contract-fixtures.md).
