# Android regression test matrix

Synthetic manifest for a debug build from Android API 24+:

```json
{"application_id":"com.example.client app B","expected_application_id":"com.example.client app B","version_code":2,"previous_version_code":1,"min_sdk":24,"device_api":35,"build_variant":"debug","required_scenarios":["cold_launch","logout","send_mock","history"],"scenarios":{"cold_launch":{"passed":true,"evidence":"CI-test-cold-launch"},"logout":{"passed":true,"evidence":"QA-log-logout"},"send_mock":{"passed":true,"evidence":"QA-log-mock-send"},"history":{"passed":true,"evidence":"QA-log-history"}},"signature_check":{"passed":true,"method":"apksigner","evidence":"CI-apksigner-log"}}
```

Do not treat template `passed:true` or an attestation string as a real result. Replace fields only after gathering actual evidence. If testing a fresh install, omit `previous_version_code`; if upgrading, versionCode must increase.

- Run `python scripts/android_regression_check.py /path/to/report.json`; nonzero means blocked.
- Verify actual signed APK separately using apksigner and a device/emulator when possible.
- Recommended mobile matrix: target phone API/version, smallest screen width, RTL Arabic layout, disconnected network, repeated taps, owner/user isolation, QR scanner permission fallback, screen rotation/back-button, persistence and app upgrade.
