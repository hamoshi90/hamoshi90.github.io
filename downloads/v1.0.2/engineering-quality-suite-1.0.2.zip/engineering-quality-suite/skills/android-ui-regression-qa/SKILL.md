---
name: android-ui-regression-qa
description: Assess Android UI regression tests, APK installation readiness, applicationId and versionCode compatibility, owner-to-user role switching, login, balance and wallet UI mock mode, permissions, device API requirements and app signing attestations. Use after Android UI changes, before handing over an APK, after a crash or install failure, and alongside Android APK Builder for Android clients with similar requirements.
---

# Android UI Regression QA

Protect existing Android behavior across code changes and app upgrades. Use alongside Android APK Builder; **this skill cannot install or run a device emulator itself**.

## Procedure
1. Establish the app's current applicationId, versionCode, signing fingerprint, `minSdk` and deployment variant. Preserve package name and signing lineage for upgrades. A debug key may not update a release-signed production installation.
2. Convert requested UX into repeatable scenarios: cold launch, email login/2FA test flow, logout, role switching, balance card correctness by role, send/receive mock-only controls, history list, offline display, retry states, loading and errors.
3. Mark every scenario as pass/fail/not run based on actual logs or screenshots, not model inference. If no device/emulator/ADB available, label as **not run**. For mock clients, verify there is no live financial transfer call.
4. After the Android build, run official `apksigner verify --verbose --print-certs <apk>` and save sanitized evidence separately; inspect minSdk and signing cert. Do not claim a signed ZIP alone proves installation compatibility.
5. Generate QA manifest and run `python scripts/android_regression_check.py /path/to/report.json` to lint attested scenarios, version upgrade and signature evidence. The script DOES NOT perform cryptographic APK signature verification or live device tests.
6. For owner-to-user role-switch designs, validate auto-switch to owner workspace and back, private vs global balances, access isolation and backward navigation. Keep unrelated wallet mock state isolated.
7. Deliver matrix of passed, failed, untested, and blockers. Attach verified APK only after Android APK Builder confirms actual build and cryptographic signature.

See [Android regression test matrix](references/android-regression-matrix.md).
