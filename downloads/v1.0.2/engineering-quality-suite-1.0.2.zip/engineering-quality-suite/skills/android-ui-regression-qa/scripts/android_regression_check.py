#!/usr/bin/env python3
"""Evaluate Android QA attestations and update constraints; cannot execute device tests."""
import argparse
import json
import re
from pathlib import Path

_PACKAGE = re.compile(r"^[A-Za-z][A-Za-z0-9_]*(\.[A-Za-z][A-Za-z0-9_]*)+$")


def audit(data):
    if not isinstance(data, dict):
        raise ValueError("Expected manifest object")
    issues = []
    app_id = data.get("application_id")
    expected_id = data.get("expected_application_id")
    if not isinstance(app_id, str) or not _PACKAGE.fullmatch(app_id):
        issues.append("INVALID_APPLICATION_ID")
    if not isinstance(expected_id, str) or app_id != expected_id:
        issues.append("APPLICATION_ID_CHANGED")
    code, old = data.get("version_code"), data.get("previous_version_code")
    if type(code) is not int or code < 1:
        issues.append("INVALID_VERSION_CODE")
    if old is not None and (type(old) is not int or type(code) is not int or code <= old):
        issues.append("UPGRADE_VERSION_CODE_NOT_INCREASED")
    min_sdk, device_api = data.get("min_sdk"), data.get("device_api")
    if type(min_sdk) is not int or not 1 <= min_sdk <= 99:
        issues.append("INVALID_MIN_SDK")
    if type(device_api) is not int or not 1 <= device_api <= 99:
        issues.append("INVALID_DEVICE_API")
    elif type(min_sdk) is int and min_sdk > device_api:
        issues.append("DEVICE_API_BELOW_MIN_SDK")
    if data.get("build_variant") != "debug":
        issues.append("NOT_DEBUG_VARIANT")
    required = data.get("required_scenarios")
    scenarios = data.get("scenarios")
    if not isinstance(required, list) or not required or not isinstance(scenarios, dict):
        issues.append("MISSING_SCENARIO_MATRIX")
    else:
        for name in required:
            if not isinstance(name, str) or not name:
                issues.append("INVALID_SCENARIO_NAME")
            elif not isinstance(scenarios.get(name), dict) or scenarios[name].get("passed") is not True:
                issues.append("SCENARIO_FAILED_OR_NOT_RUN")
            elif not isinstance(scenarios[name].get("evidence"), str) or not scenarios[name]["evidence"].strip():
                issues.append("SCENARIO_EVIDENCE_MISSING")
    att = data.get("signature_check")
    if not isinstance(att, dict) or att.get("method") != "apksigner" or att.get("passed") is not True or not isinstance(att.get("evidence"), str) or not att.get("evidence").strip():
        issues.append("SIGNATURE_ATTESTATION_MISSING")
    return {"status": "blocked" if issues else "attestations_complete", "issues": issues,
            "interpretation": "claims_require_independent_apk_and_device_log_verification"}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("report_json", type=Path)
    a = p.parse_args()
    try:
        if a.report_json.stat().st_size > 1_000_000:
            raise ValueError("Report exceeds 1 MB")
        r = audit(json.loads(a.report_json.read_text(encoding="utf-8")))
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(json.dumps({"status": "error", "error_type": type(exc).__name__}))
        return 2
    print(json.dumps(r, indent=2))
    return 0 if r["status"] == "attestations_complete" else 2


if __name__ == "__main__":
    raise SystemExit(main())
