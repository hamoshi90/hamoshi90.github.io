"""Execute seven real CLI entrypoints in-process, no network or subprocess startup."""
import contextlib
import hashlib
import io
import json
import runpy
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
CASES = [
    ('automated-security-cicd', 'security_ci_audit.py', 'security.json', 0),
    ('production-monitoring-incident-response', 'incident_triage.py', 'health.json', 0),
    ('performance-load-chaos-testing', 'offline_load_report.py', 'load.json', 0),
    ('android-e2e-automation', 'android_e2e_audit.py', 'android.json', 2),
    ('android-e2e-automation', 'android_e2e_audit.py', 'android-attestation-example-only.json', 0),
    ('multi-tenant-security-testing', 'tenant_isolation_audit.py', 'tenant.json', 0),
    ('reproducible-development-environments', 'environment_audit.py', 'environment.json', 0),
]


def cli(script, *arguments):
    capture = io.StringIO()
    argv = [str(script), *[str(v) for v in arguments]]
    with patch.object(sys, 'argv', argv), contextlib.redirect_stdout(capture):
        try:
            runpy.run_path(str(script), run_name='__main__')
        except SystemExit as e:
            code = e.code
        else:
            code = 0
    return code, json.loads(capture.getvalue()), capture.getvalue()


class CommandTests(unittest.TestCase):
    def test_each_offline_cli_matches_expected_gate(self):
        for slug, script, sample, expected in CASES:
            with self.subTest(sample=sample):
                path = ROOT / 'skills' / slug / 'scripts' / script
                code, doc, output = cli(path, '--input', ROOT/'samples'/sample)
                self.assertEqual(expected, code)
                self.assertEqual(expected == 0, doc['passed'])
                self.assertNotIn('Bearer ', output)
                self.assertNotIn('private_key', output)

    def test_backup_cli_hash_and_restore_attestation(self):
        with tempfile.TemporaryDirectory() as d:
            base = Path(d)
            (base/'mock.enc').write_bytes(b'opaque-synthetic-ciphertext')
            manifest = {'files':[{'path':'mock.enc','sha256':hashlib.sha256((base/'mock.enc').read_bytes()).hexdigest(),'encrypted':True}],
                        'restore_drill':{'performed':True,'isolated':True,'integrity_ok':True,'point_in_time_checked':True,'elapsed_seconds':3},
                        'rpo_seconds':1,'max_rpo_seconds':10,'rto_seconds':3,'max_rto_seconds':10}
            (base/'manifest.json').write_text(json.dumps(manifest), encoding='utf-8')
            script=ROOT/'skills/disaster-recovery-backup-verification/scripts/backup_verify.py'
            code, result, _=cli(script,'--manifest',base/'manifest.json','--root',base)
            self.assertEqual(0,code)
            self.assertTrue(result['passed'])
            (base/'mock.enc').write_bytes(b'changed')
            code, result, _=cli(script,'--manifest',base/'manifest.json','--root',base)
            self.assertEqual(2,code)
            self.assertFalse(result['passed'])

    def test_root_manifest_and_7_skills(self):
        manifest=json.loads((ROOT/'plugin.json').read_text('utf-8'))
        self.assertEqual('production-excellence-suite',manifest['name'])
        self.assertEqual('1.0.2',manifest['version'])
        self.assertLessEqual(len(manifest['extensions']['com.openai']['interface']['shortDescription']),30)
        names=[]
        for p in (ROOT/'skills').glob('*/SKILL.md'):
            s=p.read_text('utf-8')
            self.assertIn('allow_implicit_invocation: true',(p.parent/'agents/openai.yaml').read_text('utf-8'))
            self.assertIn('never mix',s)
            self.assertIn('description:',s)
            names.append(p.parent.name)
        self.assertEqual(7,len(names))
        self.assertEqual(7,len(set(names)))


if __name__=='__main__': unittest.main()
