"""Pure, synthetic, offline evidence tests for seven Production Excellence skills."""
import hashlib
import importlib.util
import json
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def load(skill, filename):
    path = ROOT / 'skills' / skill / 'scripts' / filename
    spec = importlib.util.spec_from_file_location(skill.replace('-', '_'), path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class SecurityTests(unittest.TestCase):
    def setUp(self):
        self.module = load('automated-security-cicd', 'security_ci_audit.py')
        self.base = {
            'ci': {'tests_run': True, 'static_analysis': True, 'dependency_scan': True,
                   'secret_scan': True, 'least_privilege_token': True},
            'dependency_vulnerabilities': {'critical': 0, 'high': 0},
            'files': [{'path': 'app/main.py', 'content': 'def hello(): return "hello"'}]
        }
    def test_passing_evidence(self):
        self.assertTrue(self.module.evaluate(self.base)['passed'])
    def test_missing_ci_gate_fails_closed(self):
        d = json.loads(json.dumps(self.base)); del d['ci']['secret_scan']
        self.assertFalse(self.module.evaluate(d)['passed'])
    def test_detects_private_key_marker_without_echo(self):
        d = json.loads(json.dumps(self.base)); d['files'] = [{'path': 'secret.txt', 'content': '-----BEGIN ' + 'PRIVATE KEY-----abc-----END PRIVATE KEY-----'}]
        out = self.module.evaluate(d)
        self.assertFalse(out['passed']); self.assertNotIn('abc', json.dumps(out))
    def test_high_vulnerability_fails(self):
        d = json.loads(json.dumps(self.base)); d['dependency_vulnerabilities']['high'] = 1
        self.assertFalse(self.module.evaluate(d)['passed'])
    def test_rejects_incomplete_evidence(self):
        self.assertFalse(self.module.evaluate({})['passed'])


class MonitoringTests(unittest.TestCase):
    def setUp(self):
        self.module = load('production-monitoring-incident-response', 'incident_triage.py')
        self.good = {'services':[{'name':'api', 'healthy':True,'error_rate':0.01,'p95_ms':200,
                                  'last_success_seconds':20,'limits':{'max_error_rate':0.05,
                                  'max_p95_ms':300,'max_last_success_seconds':120}}]}
    def test_healthy(self):
        self.assertTrue(self.module.evaluate(self.good)['passed'])
    def test_down_service_alert(self):
        d=json.loads(json.dumps(self.good));d['services'][0]['healthy']=False
        self.assertEqual('critical',self.module.evaluate(d)['severity'])
    def test_high_error_rate(self):
        d=json.loads(json.dumps(self.good));d['services'][0]['error_rate']=0.07
        self.assertFalse(self.module.evaluate(d)['passed'])
    def test_stale_activity(self):
        d=json.loads(json.dumps(self.good));d['services'][0]['last_success_seconds']=400
        self.assertFalse(self.module.evaluate(d)['passed'])
    def test_missing_threshold_not_green(self):
        d=json.loads(json.dumps(self.good));del d['services'][0]['limits']
        self.assertFalse(self.module.evaluate(d)['passed'])


class LoadTests(unittest.TestCase):
    def setUp(self):
        self.module = load('performance-load-chaos-testing', 'offline_load_report.py')
        self.good={'samples':[{'duration_ms':40,'status':200},{'duration_ms':70,'status':200},
                              {'duration_ms':90,'status':200},{'duration_ms':100,'status':200}],
                   'limits':{'max_p95_ms':120,'max_error_rate':0.05,'min_samples':4},
                   'chaos':[{'name':'disconnect','recovered':True,'duplicate_financial_ops':0}]}
    def test_acceptable_performance(self):
        self.assertTrue(self.module.evaluate(self.good)['passed'])
    def test_slow_p95(self):
        d=json.loads(json.dumps(self.good));d['samples'][-1]['duration_ms']=400
        self.assertFalse(self.module.evaluate(d)['passed'])
    def test_high_error_rate(self):
        d=json.loads(json.dumps(self.good));d['samples'][0]['status']=500
        self.assertFalse(self.module.evaluate(d)['passed'])
    def test_failed_recovery(self):
        d=json.loads(json.dumps(self.good));d['chaos'][0]['recovered']=False
        self.assertFalse(self.module.evaluate(d)['passed'])
    def test_duplicate_financial_ops(self):
        d=json.loads(json.dumps(self.good));d['chaos'][0]['duplicate_financial_ops']=1
        self.assertFalse(self.module.evaluate(d)['passed'])
    def test_empty_samples(self):
        self.assertFalse(self.module.evaluate({'samples':[]})['passed'])


class AndroidTests(unittest.TestCase):
    def setUp(self):
        self.module=load('android-e2e-automation', 'android_e2e_audit.py')
        self.good={'required_flows':['login','balance','send-mock','receive-mock','history'],
                   'flows':[{'name':n,'assertions':['screen-visible'],'uses_real_funds':False}
                            for n in ['login','balance','send-mock','receive-mock','history']],
                   'device_run':{'executed':True,'runner':'maestro','failed':0,'passed':5,
                                 'apk_signature_verified':True}}
    def test_device_evidence_pass(self):
        self.assertTrue(self.module.evaluate(self.good)['passed'])
    def test_missing_flow(self):
        d=json.loads(json.dumps(self.good));d['flows'].pop()
        self.assertFalse(self.module.evaluate(d)['passed'])
    def test_preview_only_does_not_pass_device_gate(self):
        d=json.loads(json.dumps(self.good));d['device_run']['executed']=False
        self.assertFalse(self.module.evaluate(d)['passed'])
    def test_no_assertions_fails(self):
        d=json.loads(json.dumps(self.good));d['flows'][0]['assertions']=[]
        self.assertFalse(self.module.evaluate(d)['passed'])
    def test_live_funds_disallowed(self):
        d=json.loads(json.dumps(self.good));d['flows'][2]['uses_real_funds']=True
        self.assertFalse(self.module.evaluate(d)['passed'])
    def test_failures_block(self):
        d=json.loads(json.dumps(self.good));d['device_run']['failed']=1
        self.assertFalse(self.module.evaluate(d)['passed'])


class BackupTests(unittest.TestCase):
    def setUp(self):
        self.module=load('disaster-recovery-backup-verification', 'backup_verify.py')
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.path=Path(self.tmp.name)
        (self.path/'backup.enc').write_bytes(b'synthetic encrypted backup payload')
        digest=hashlib.sha256((self.path/'backup.enc').read_bytes()).hexdigest()
        self.manifest={'files':[{'path':'backup.enc','sha256':digest,'encrypted':True}],
                       'restore_drill':{'performed':True,'isolated':True,'integrity_ok':True,
                                        'point_in_time_checked':True,'elapsed_seconds':25},
                       'rpo_seconds':100,'max_rpo_seconds':300,
                       'rto_seconds':25,'max_rto_seconds':120}
    def test_verified_backup(self):
        self.assertTrue(self.module.evaluate(self.manifest,self.path)['passed'])
    def test_tampered_file(self):
        (self.path/'backup.enc').write_bytes(b'tampered')
        self.assertFalse(self.module.evaluate(self.manifest,self.path)['passed'])
    def test_path_traversal_rejected(self):
        self.manifest['files'][0]['path']='../outside'
        self.assertFalse(self.module.evaluate(self.manifest,self.path)['passed'])
    def test_unencrypted_backup_rejected(self):
        self.manifest['files'][0]['encrypted']=False
        self.assertFalse(self.module.evaluate(self.manifest,self.path)['passed'])
    def test_restore_not_tested_fails(self):
        self.manifest['restore_drill']['performed']=False
        self.assertFalse(self.module.evaluate(self.manifest,self.path)['passed'])
    def test_slow_restore_fails(self):
        self.manifest['rto_seconds']=200
        self.assertFalse(self.module.evaluate(self.manifest,self.path)['passed'])
    def test_symlink_escape_rejected(self):
        outside=self.path.parent / ('outside-'+self.path.name)
        outside.write_bytes(b'data');self.addCleanup(lambda:outside.unlink(missing_ok=True))
        (self.path/'escape').symlink_to(outside)
        self.manifest['files'][0]['path']='escape'
        self.assertFalse(self.module.evaluate(self.manifest,self.path)['passed'])


class TenantTests(unittest.TestCase):
    def setUp(self):
        self.module=load('multi-tenant-security-testing', 'tenant_isolation_audit.py')
        self.good={'required_operations':['read','write','list'],
                   'cases':[{'actor_tenant':'a','resource_tenant':'b','actor_role':'user','operation':op,
                             'requires_role':'user','decision':'deny'} for op in ['read','write','list']] +
                           [{'actor_tenant':'a','resource_tenant':'a','actor_role':'user','operation':'admin',
                             'requires_role':'owner','decision':'deny'}]}
    def test_all_denied(self):
        self.assertTrue(self.module.evaluate(self.good)['passed'])
    def test_cross_tenant_access(self):
        d=json.loads(json.dumps(self.good));d['cases'][0]['decision']='allow'
        self.assertFalse(self.module.evaluate(d)['passed'])
    def test_missing_operation(self):
        d=json.loads(json.dumps(self.good));d['cases']=d['cases'][1:]
        self.assertFalse(self.module.evaluate(d)['passed'])
    def test_privilege_escalation(self):
        d=json.loads(json.dumps(self.good));d['cases'][-1]['decision']='allow'
        self.assertFalse(self.module.evaluate(d)['passed'])
    def test_no_coverage_cannot_pass(self):
        self.assertFalse(self.module.evaluate({})['passed'])


class EnvironmentTests(unittest.TestCase):
    def setUp(self):
        self.module=load('reproducible-development-environments','environment_audit.py')
        self.good={'services':{'api':{'image':'my-app:1.2.0','healthcheck':True,'uses_plaintext_secrets':False},
                               'db':{'image':'postgres:16.6','healthcheck':True,'uses_plaintext_secrets':False}},
                   'lockfiles':['requirements.lock'],'env_example':True,'tests_reproducible':True,
                   'committed_real_secrets':False}
    def test_pinned_images(self):
        self.assertTrue(self.module.evaluate(self.good)['passed'])
    def test_latest_image_forbidden(self):
        d=json.loads(json.dumps(self.good));d['services']['api']['image']='my-app:latest'
        self.assertFalse(self.module.evaluate(d)['passed'])
    def test_no_healthcheck(self):
        d=json.loads(json.dumps(self.good));d['services']['db']['healthcheck']=False
        self.assertFalse(self.module.evaluate(d)['passed'])
    def test_real_secrets_committed(self):
        d=json.loads(json.dumps(self.good));d['committed_real_secrets']=True
        self.assertFalse(self.module.evaluate(d)['passed'])
    def test_missing_lockfile(self):
        d=json.loads(json.dumps(self.good));d['lockfiles']=[]
        self.assertFalse(self.module.evaluate(d)['passed'])
    def test_no_evidence_fails(self):
        self.assertFalse(self.module.evaluate({})['passed'])


if __name__=='__main__':unittest.main()
