# Automated Security & CI/CD: field guide

Audit sanitized evidence for tests, static analysis, dependency scanning, secret scanning and minimal CI token permissions. Configure real scanners on approved repositories; never treat a self-reported fixture as a security certification.

## Acceptance criteria

- Identify exact repository, approved baseline, languages, and existing CI pipelines; make no writes until source and deployment target are confirmed.
- Review workflow trust boundaries, triggers, permissions, pull-request forks, dependency audit results, SBOM and secret scanning. Do not read, print or store real tokens.
- Build sanitized evidence JSON; run the offline CLI and inspect nonzero exit status. Do not infer a clean repo from this script alone.
- Propose or implement CI workflows only on an explicitly authorized branch; require branch protection and human review for production merges.
- Run actual CodeQL, unit tests, dependency scanning and secret-scanning gates in CI; report their real logs independently from the offline evidence check.

## Limitations and caveats

Escalate leaked keys for rotation outside chat. A regex review detects only selected patterns; comprehensive SAST and DAST must be separately run. Template workflows under assets/templates are opt-in examples; pin GitHub Actions to audited full commit SHAs before production.

## Evidence classification

- `verified`: directly observed tool output, test log, or execution trace on the named environment.
- `self-reported`: supplied JSON/attestation whose truth was not independently checked.
- `planned`: design, documentation, or example workflow that has not been deployed.

Do not promote `self-reported` or `planned` to `verified`.
