"""Offline, sanitized CI/security evidence review; not a SAST scanner."""
import argparse
import json
import re

GATES = ('tests_run', 'static_analysis', 'dependency_scan', 'secret_scan', 'least_privilege_token')
SECRET_PATTERNS = (
    re.compile(r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----'),
    re.compile(r'\bgh[pousr]_[A-Za-z0-9]{20,}'),
    re.compile(r'\bsk-proj-[A-Za-z0-9_-]{15,}'),
)


def evaluate(data):
    errors = []
    if not isinstance(data, dict):
        return {'passed': False, 'failures': ['Input must be a JSON object.']}
    ci = data.get('ci')
    if not isinstance(ci, dict):
        errors.append('Missing CI evidence object.')
        ci = {}
    for gate in GATES:
        if ci.get(gate) is not True:
            errors.append('CI gate not confirmed: ' + gate)
    vulns = data.get('dependency_vulnerabilities')
    if not isinstance(vulns, dict):
        errors.append('Missing dependency audit evidence.')
    else:
        for level in ('critical', 'high'):
            value = vulns.get(level)
            if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                errors.append('Invalid or missing vulnerability count: ' + level)
            elif value > 0:
                errors.append('Blocking dependency vulnerabilities: ' + level)
    files = data.get('files')
    if not isinstance(files, list) or not files:
        errors.append('No source scan evidence supplied.')
    else:
        for item in files:
            if not isinstance(item, dict) or not isinstance(item.get('content'), str):
                errors.append('Invalid source scan evidence.')
                continue
            if any(p.search(item['content']) for p in SECRET_PATTERNS):
                errors.append('Potential embedded secret detected. Content intentionally withheld.')
    if data.get('exposed_secrets') is True:
        errors.append('Reported exposed secret requires rotation and removal.')
    return {'passed': not errors, 'checked_files': len(files) if isinstance(files, list) else 0,
            'failures': sorted(set(errors)), 'note': 'Offline evidence review only, not code execution or live secret scanning.'}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', required=True, help='Sanitized JSON CI evidence')
    args = p.parse_args()
    try:
        with open(args.input, encoding='utf-8') as f:
            result = evaluate(json.load(f))
    except (OSError, ValueError, TypeError):
        result = {'passed': False, 'failures': ['Invalid/unreadable evidence file.']}
    print(json.dumps(result, sort_keys=True))
    raise SystemExit(0 if result['passed'] else 2)


if __name__ == '__main__':
    main()
