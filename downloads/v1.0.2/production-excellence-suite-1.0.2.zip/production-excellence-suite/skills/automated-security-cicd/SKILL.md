---
name: automated-security-cicd
description: "Use when setting up GitHub Actions, PR quality gates, CodeQL, dependency scans, leaked-secret detection, or reviewing a secure CI pipeline for a release."
---

# Automated Security & CI/CD

Audit sanitized evidence for tests, static analysis, dependency scanning, secret scanning and minimal CI token permissions. Configure real scanners on approved repositories; never treat a self-reported fixture as a security certification.

## Evidence-first workflow

1. Identify exact repository, approved baseline, languages, and existing CI pipelines; make no writes until source and deployment target are confirmed.
2. Review workflow trust boundaries, triggers, permissions, pull-request forks, dependency audit results, SBOM and secret scanning. Do not read, print or store real tokens.
3. Build sanitized evidence JSON; run the offline CLI and inspect nonzero exit status. Do not infer a clean repo from this script alone.
4. Propose or implement CI workflows only on an explicitly authorized branch; require branch protection and human review for production merges.
5. Run actual CodeQL, unit tests, dependency scanning and secret-scanning gates in CI; report their real logs independently from the offline evidence check.

## Bundled offline checker

From a local workspace with Python 3.11+:

```bash
python scripts/security_ci_audit.py --input /path/to/sanitized-security-evidence.json
```

The checker prints JSON and returns exit code `0` only when all specified evidence gates pass; `2` means blocked or incomplete evidence. It **never runs live external actions**. Its `passed` flag only evaluates supplied evidence.

## Required safety boundaries

- Unrelated applications and their tenants are separate projects: never mix their secrets, wallet sessions, databases, source branches, test credentials or baselines.
- Default to mock/sandbox and read-only analysis. Live funds, public publishing, altering production permissions, destructive tests, network load, or privileged actions need separate explicit approval.
- Never represent an offline synthetic-fixture success as production readiness, security certification, APK device validation, or deployment completion.
- Preserve the currently approved release baseline for each project. For production releases, also invoke `production-release-gatekeeper` and `verification-before-completion`.

## Reference

Read `references/security-ci-checklist.md` for scenario-specific controls and acceptance criteria.
