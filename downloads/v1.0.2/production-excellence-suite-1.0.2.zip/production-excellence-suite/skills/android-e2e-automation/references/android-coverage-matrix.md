# Android End-to-End Automation: field guide

Review Android E2E test coverage, device execution evidence and APK signature verification; distinguish interactive chat previews from genuine emulator runs.

## Acceptance criteria

- Resolve the app source, approved baseline, applicationId, versionCode, UI language/RTL, exact theme and state of previous APK.
- Use Interactive App Preview for source-faithful presentation; it is NOT a substitute for a real Android emulator or device.
- Define named assertions for login, balance, send-mock, receive-mock, history, logout and role switching where implemented; check accessibility identifiers and secure test credentials.
- Run offline evidence auditor. No device run, missing assertions or real-money test flows must block a device-ready claim.
- When SDK/runner is present and execution is authorized, compile APK, run Maestro/Appium/Espresso on emulator/device, collect anonymized screenshots/logs and apksigner verification.
- Report actual observed failures, accessibility/RTL regressions, artifacts and signing verification separately from self-reported fixtures.

## Limitations and caveats

The template Maestro flow has replaceable placeholders and has not been executed on Android. Keep mock wallet send/receive isolated from production sessions.

## Evidence classification

- `verified`: directly observed tool output, test log, or execution trace on the named environment.
- `self-reported`: supplied JSON/attestation whose truth was not independently checked.
- `planned`: design, documentation, or example workflow that has not been deployed.

Do not promote `self-reported` or `planned` to `verified`.
