"""Audit an Android offline-test plan and self-reported device test evidence."""
import argparse
import json

ALLOWED_RUNNERS = {'maestro', 'appium', 'espresso', 'uiautomator'}


def evaluate(data):
    issues = []
    if not isinstance(data, dict):
        return {'passed': False, 'issues': ['Missing E2E evidence.']}
    required, flows = data.get('required_flows'), data.get('flows')
    if not isinstance(required, list) or not required or any(not isinstance(x, str) or not x for x in required):
        issues.append('No valid required flow list.')
        required = []
    if not isinstance(flows, list):
        issues.append('No valid E2E flow definitions.')
        flows = []
    names = set()
    for flow in flows:
        if not isinstance(flow, dict) or not isinstance(flow.get('name'), str):
            issues.append('Invalid test flow.')
            continue
        names.add(flow['name'])
        if not isinstance(flow.get('assertions'), list) or not flow['assertions']:
            issues.append('Flow missing screen/state assertions.')
        if flow.get('uses_real_funds') is not False:
            issues.append('Real-money or unspecified finance operation in E2E plan.')
    if set(required) - names:
        issues.append('Required E2E flow missing.')
    if len(set(required)) != len(required):
        issues.append('Duplicate required flow identifier.')
    run = data.get('device_run')
    if not isinstance(run, dict):
        issues.append('No Android device/emulator test evidence.')
    else:
        if run.get('executed') is not True:
            issues.append('Preview or plan only; Android tests were not executed.')
        if run.get('runner') not in ALLOWED_RUNNERS:
            issues.append('Unknown Android test runner.')
        if type(run.get('failed')) is not int or run['failed'] != 0:
            issues.append('Failed or missing Android test count.')
        if type(run.get('passed')) is not int or run['passed'] <= 0:
            issues.append('No passing device tests attested.')
        if run.get('apk_signature_verified') is not True:
            issues.append('APK signature verification not attested.')
    return {'passed': not issues, 'defined_flows': len(names), 'required_flows': len(required),
            'issues': sorted(set(issues)),
            'note': 'Self-reported evidence is not a substitute for actual emulator logs, screenshots and apksigner output.'}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', required=True)
    args = p.parse_args()
    try:
        with open(args.input, encoding='utf-8') as f:
            result = evaluate(json.load(f))
    except (OSError, ValueError, TypeError):
        result = {'passed': False, 'issues': ['Unreadable test evidence.']}
    print(json.dumps(result, sort_keys=True))
    raise SystemExit(0 if result['passed'] else 2)


if __name__ == '__main__':
    main()
