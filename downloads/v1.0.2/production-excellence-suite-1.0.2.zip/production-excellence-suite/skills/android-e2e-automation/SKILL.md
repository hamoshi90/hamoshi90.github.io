---
name: android-e2e-automation
description: "Use when planning or running real Android emulator/device end-to-end tests, Maestro, Appium, Espresso, login, owner role switching, wallet mock flows, APK signing or screenshot regression."
---

# Android End-to-End Automation

Review Android E2E test coverage, device execution evidence and APK signature verification; distinguish interactive chat previews from genuine emulator runs.

## Evidence-first workflow

1. Resolve the app source, approved baseline, applicationId, versionCode, UI language/RTL, exact theme and state of previous APK.
2. Use Interactive App Preview for source-faithful presentation; it is NOT a substitute for a real Android emulator or device.
3. Define named assertions for login, balance, send-mock, receive-mock, history, logout and role switching where implemented; check accessibility identifiers and secure test credentials.
4. Run offline evidence auditor. No device run, missing assertions or real-money test flows must block a device-ready claim.
5. When SDK/runner is present and execution is authorized, compile APK, run Maestro/Appium/Espresso on emulator/device, collect anonymized screenshots/logs and apksigner verification.
6. Report actual observed failures, accessibility/RTL regressions, artifacts and signing verification separately from self-reported fixtures.

## Bundled offline checker

From a local workspace with Python 3.11+:

```bash
python scripts/android_e2e_audit.py --input /path/to/android-test-evidence.json
```

The checker prints JSON and returns exit code `0` only when all specified evidence gates pass; `2` means blocked or incomplete evidence. It **never runs live external actions**. Its `passed` flag only evaluates supplied evidence.

## Required safety boundaries

- Unrelated applications and their tenants are separate projects: never mix their secrets, wallet sessions, databases, source branches, test credentials or baselines.
- Default to mock/sandbox and read-only analysis. Live funds, public publishing, altering production permissions, destructive tests, network load, or privileged actions need separate explicit approval.
- Never represent an offline synthetic-fixture success as production readiness, security certification, APK device validation, or deployment completion.
- Preserve the currently approved release baseline for each project. For production releases, also invoke `production-release-gatekeeper` and `verification-before-completion`.

## Reference

Read `references/android-coverage-matrix.md` for scenario-specific controls and acceptance criteria.
