---
name: performance-load-chaos-testing
description: "Use when users ask for load tests, stress tests, concurrency, latency p95, recovery from internet outages, retry storms, idempotency under failures, or capacity planning."
---

# Performance, Load & Chaos Testing

Analyze performance samples and simulated fault-injection outcomes offline, checking latency/error budgets and duplicate financial operations without generating traffic.

## Evidence-first workflow

1. Confirm application, deployment environment, exact test scope and explicit authorization before any active load generation. Default to offline reports or local mock/staging.
2. Set ceilings for requests per second, concurrent users, duration, test accounts and kill switches; explicitly prohibit live money transfers.
3. Collect p50/p95/p99, request error rate, CPU/memory, recovery times, retry and duplicate operation markers from isolated tests.
4. Run offline script against sanitized samples and chaos recovery outcomes. Missing samples or thresholds must fail closed.
5. If and only if authorized, run k6/Locust or controlled fault injection against owned staging services, then analyze traces; never target production by default.
6. Report capacity only with real execution evidence, infrastructure details, sample sizes and test-tool limitations.

## Bundled offline checker

From a local workspace with Python 3.11+:

```bash
python scripts/offline_load_report.py --input /path/to/load-samples.json
```

The checker prints JSON and returns exit code `0` only when all specified evidence gates pass; `2` means blocked or incomplete evidence. It **never runs live external actions**. Its `passed` flag only evaluates supplied evidence.

## Required safety boundaries

- Unrelated applications and their tenants are separate projects: never mix their secrets, wallet sessions, databases, source branches, test credentials or baselines.
- Default to mock/sandbox and read-only analysis. Live funds, public publishing, altering production permissions, destructive tests, network load, or privileged actions need separate explicit approval.
- Never represent an offline synthetic-fixture success as production readiness, security certification, APK device validation, or deployment completion.
- Preserve the currently approved release baseline for each project. For production releases, also invoke `production-release-gatekeeper` and `verification-before-completion`.

## Reference

Read `references/safe-load-chaos-plan.md` for scenario-specific controls and acceptance criteria.
