# Performance, Load & Chaos Testing: field guide

Analyze performance samples and simulated fault-injection outcomes offline, checking latency/error budgets and duplicate financial operations without generating traffic.

## Acceptance criteria

- Confirm application, deployment environment, exact test scope and explicit authorization before any active load generation. Default to offline reports or local mock/staging.
- Set ceilings for requests per second, concurrent users, duration, test accounts and kill switches; explicitly prohibit live money transfers.
- Collect p50/p95/p99, request error rate, CPU/memory, recovery times, retry and duplicate operation markers from isolated tests.
- Run offline script against sanitized samples and chaos recovery outcomes. Missing samples or thresholds must fail closed.
- If and only if authorized, run k6/Locust or controlled fault injection against owned staging services, then analyze traces; never target production by default.
- Report capacity only with real execution evidence, infrastructure details, sample sizes and test-tool limitations.

## Limitations and caveats

Handle ambiguous financial transfer outcomes using status verification rather than retrying a send. The analyzer cannot perform network load or chaos execution.

## Evidence classification

- `verified`: directly observed tool output, test log, or execution trace on the named environment.
- `self-reported`: supplied JSON/attestation whose truth was not independently checked.
- `planned`: design, documentation, or example workflow that has not been deployed.

Do not promote `self-reported` or `planned` to `verified`.
