"""Analyze synthetic/offline load and recovery results; sends no traffic."""
import argparse
import json
import math


def number(x, minimum=0, maximum=float('inf')):
    return type(x) in (int, float) and math.isfinite(x) and minimum <= x <= maximum


def evaluate(data):
    reasons = []
    if not isinstance(data, dict):
        return {'passed': False, 'reasons': ['Input must be a JSON object.']}
    samples = data.get('samples')
    limits = data.get('limits')
    if not isinstance(samples, list) or not samples:
        reasons.append('No measured request samples.')
        samples = []
    if not isinstance(limits, dict) or not (number(limits.get('max_p95_ms')) and
                                           number(limits.get('max_error_rate'), maximum=1) and
                                           type(limits.get('min_samples')) is int and limits['min_samples'] > 0):
        reasons.append('Missing or invalid performance thresholds.')
        limits = None
    valid = []
    for sample in samples:
        if (not isinstance(sample, dict) or not number(sample.get('duration_ms')) or
                type(sample.get('status')) is not int or not 100 <= sample['status'] <= 599):
            reasons.append('Invalid request sample.')
        else:
            valid.append(sample)
    duration = sorted(s['duration_ms'] for s in valid)
    p95 = duration[math.ceil(.95 * len(duration)) - 1] if duration else None
    error_rate = sum(s['status'] >= 400 for s in valid) / len(valid) if valid else None
    if limits and valid:
        if len(valid) < limits['min_samples']:
            reasons.append('Insufficient sample size.')
        if p95 > limits['max_p95_ms']:
            reasons.append('p95 latency exceeds maximum.')
        if error_rate > limits['max_error_rate']:
            reasons.append('Error rate exceeds maximum.')
    chaos = data.get('chaos', [])
    if not isinstance(chaos, list):
        reasons.append('Invalid chaos evidence.')
        chaos = []
    for case in chaos:
        if not isinstance(case, dict) or case.get('recovered') is not True:
            reasons.append('Recovery scenario did not pass.')
        if (not isinstance(case, dict) or type(case.get('duplicate_financial_ops')) is not int or
                case['duplicate_financial_ops'] != 0):
            reasons.append('Potential duplicate financial operation in recovery scenario.')
    return {'passed': not reasons, 'sample_count': len(valid), 'p95_ms': p95, 'error_rate': error_rate,
            'chaos_cases': len(chaos), 'reasons': sorted(set(reasons)),
            'note': 'This report does not generate load or prove production capacity.'}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', required=True)
    args = p.parse_args()
    try:
        with open(args.input, encoding='utf-8') as f:
            result = evaluate(json.load(f))
    except (OSError, ValueError, TypeError):
        result = {'passed': False, 'reasons': ['Unreadable evidence.']}
    print(json.dumps(result, sort_keys=True))
    raise SystemExit(0 if result['passed'] else 2)


if __name__ == '__main__':
    main()
