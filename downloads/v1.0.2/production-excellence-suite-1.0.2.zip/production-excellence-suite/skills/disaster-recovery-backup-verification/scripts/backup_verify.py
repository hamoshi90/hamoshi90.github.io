"""Read-only encrypted backup integrity and isolated-restore drill evidence gate."""
import argparse
import hashlib
import json
from pathlib import Path


def _digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        while True:
            block = f.read(1024 * 1024)
            if not block:
                break
            h.update(block)
    return h.hexdigest()


def _nonnegative_number(v):
    import math
    return type(v) in (int, float) and math.isfinite(v) and v >= 0


def evaluate(data, root):
    issues = []
    base = Path(root).resolve()
    if not isinstance(data, dict):
        return {'passed': False, 'issues': ['Invalid manifest.']}
    entries = data.get('files')
    if not isinstance(entries, list) or not entries:
        issues.append('No backup files in manifest.')
        entries = []
    for entry in entries:
        if not isinstance(entry, dict) or not isinstance(entry.get('path'), str) or not entry['path']:
            issues.append('Invalid backup path entry.')
            continue
        rel = Path(entry['path'])
        candidate = (base / rel).resolve()
        # Never read another directory or follow an untrusted symbolic link.
        if rel.is_absolute() or '..' in rel.parts or not candidate.is_relative_to(base) or candidate.is_symlink() or (base / rel).is_symlink():
            issues.append('Backup path traversal or symlink detected.')
            continue
        if not candidate.is_file():
            issues.append('Backup file missing.')
            continue
        expected = entry.get('sha256')
        if not isinstance(expected, str) or len(expected) != 64 or any(c not in '0123456789abcdefABCDEF' for c in expected):
            issues.append('Invalid SHA-256 manifest entry.')
        elif _digest(candidate).lower() != expected.lower():
            issues.append('Backup checksum mismatch.')
        if entry.get('encrypted') is not True:
            issues.append('Backup encryption not confirmed.')
    drill = data.get('restore_drill')
    if not isinstance(drill, dict) or any(drill.get(k) is not True for k in
                                          ('performed', 'isolated', 'integrity_ok', 'point_in_time_checked')):
        issues.append('Isolated restore and point-in-time drill not attested.')
    else:
        if not _nonnegative_number(drill.get('elapsed_seconds')):
            issues.append('Invalid restore drill elapsed time.')
    for observed, maximum in (('rpo_seconds', 'max_rpo_seconds'), ('rto_seconds', 'max_rto_seconds')):
        a, b = data.get(observed), data.get(maximum)
        if not _nonnegative_number(a) or not _nonnegative_number(b):
            issues.append('Invalid RPO/RTO evidence.')
        elif a > b:
            issues.append('RPO/RTO objective exceeded.')
    return {'passed': not issues, 'files_checked': len(entries), 'issues': sorted(set(issues)),
            'note': 'SHA-256 and drill metadata checked; no restore was performed by this script.'}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--manifest', required=True)
    p.add_argument('--root', required=True)
    args = p.parse_args()
    try:
        with open(args.manifest, encoding='utf-8') as f:
            result = evaluate(json.load(f), args.root)
    except (OSError, ValueError, TypeError):
        result = {'passed': False, 'issues': ['Unreadable manifest.']}
    print(json.dumps(result, sort_keys=True))
    raise SystemExit(0 if result['passed'] else 2)


if __name__ == '__main__':
    main()
