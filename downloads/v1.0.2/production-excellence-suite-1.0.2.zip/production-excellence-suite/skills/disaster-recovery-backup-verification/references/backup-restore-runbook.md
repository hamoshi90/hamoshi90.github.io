# Disaster Recovery & Backup Verification: field guide

Verify local backup files by SHA-256, prevent path escapes, and gate readiness on recorded isolated restore drills and RPO/RTO evidence. Never extract or restore data implicitly.

## Acceptance criteria

- Confirm the project and data class; preserve its approved baseline and never mix project databases, keys, sessions or encryption secrets.
- Use encrypted local snapshots, off-host retention, immutable backup policies and access controls appropriate to the data; never copy production secrets into the report.
- Read a SANITIZED manifest of relative backup paths, expected SHA-256 and encrypted flags; run bundled read-only verifier against local supplied directory.
- Perform an actual isolated restore drill only with explicit user authorization and a safe nonproduction destination; verify migrations and application integrity.
- Compare observed restore duration and recovery point against approved RTO/RPO targets, then document rollback and incident procedures.
- Do not say the backup is restorable solely because a hash matches or an attestation says restore succeeded.

## Limitations and caveats

The verifier hashes contents read-only; encrypted=true is provided evidence, not cryptographic proof that bytes are encrypted. Never accept symlink/path traversal or touch source backup files.

## Evidence classification

- `verified`: directly observed tool output, test log, or execution trace on the named environment.
- `self-reported`: supplied JSON/attestation whose truth was not independently checked.
- `planned`: design, documentation, or example workflow that has not been deployed.

Do not promote `self-reported` or `planned` to `verified`.
