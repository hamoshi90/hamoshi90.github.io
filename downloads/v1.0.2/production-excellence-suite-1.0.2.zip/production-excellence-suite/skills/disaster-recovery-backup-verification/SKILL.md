---
name: disaster-recovery-backup-verification
description: "Use when validating encrypted backups, hash integrity, backup frequency, disaster recovery, RPO/RTO, offline restore drills, point-in-time recovery or rollbacks."
---

# Disaster Recovery & Backup Verification

Verify local backup files by SHA-256, prevent path escapes, and gate readiness on recorded isolated restore drills and RPO/RTO evidence. Never extract or restore data implicitly.

## Evidence-first workflow

1. Confirm the project and data class; preserve its approved baseline and never mix project databases, keys, sessions or encryption secrets.
2. Use encrypted local snapshots, off-host retention, immutable backup policies and access controls appropriate to the data; never copy production secrets into the report.
3. Read a SANITIZED manifest of relative backup paths, expected SHA-256 and encrypted flags; run bundled read-only verifier against local supplied directory.
4. Perform an actual isolated restore drill only with explicit user authorization and a safe nonproduction destination; verify migrations and application integrity.
5. Compare observed restore duration and recovery point against approved RTO/RPO targets, then document rollback and incident procedures.
6. Do not say the backup is restorable solely because a hash matches or an attestation says restore succeeded.

## Bundled offline checker

From a local workspace with Python 3.11+:

```bash
python scripts/backup_verify.py --manifest /path/to/sanitized-manifest.json --root /path/to/backup-directory
```

The checker prints JSON and returns exit code `0` only when all specified evidence gates pass; `2` means blocked or incomplete evidence. It **never runs live external actions**. Its `passed` flag only evaluates supplied evidence.

## Required safety boundaries

- Unrelated applications and their tenants are separate projects: never mix their secrets, wallet sessions, databases, source branches, test credentials or baselines.
- Default to mock/sandbox and read-only analysis. Live funds, public publishing, altering production permissions, destructive tests, network load, or privileged actions need separate explicit approval.
- Never represent an offline synthetic-fixture success as production readiness, security certification, APK device validation, or deployment completion.
- Preserve the currently approved release baseline for each project. For production releases, also invoke `production-release-gatekeeper` and `verification-before-completion`.

## Reference

Read `references/backup-restore-runbook.md` for scenario-specific controls and acceptance criteria.
