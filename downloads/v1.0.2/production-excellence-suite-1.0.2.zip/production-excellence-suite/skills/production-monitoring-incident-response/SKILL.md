---
name: production-monitoring-incident-response
description: "Use when monitoring uptime, errors, latency, runtime health, incidents, flaky integration sessions, uptime reports, alert thresholds, or postmortems for production apps and bots."
---

# Production Monitoring & Incident Response

Assess sanitized snapshots of service health, request error rate, p95 latency and last-success freshness; produce evidence-based severity without contacting live services.

## Evidence-first workflow

1. Resolve which independent project and deployment are affected; identify owned service names and approved telemetry channels.
2. Define health signals, thresholds, SLOs, alert ownership, deduplication, incident severity and rollback actions before production.
3. Use PostHog if connected for opt-in product analytics, errors and feature rollout events; use Datadog if separately connected for service metrics/traces, never assume either is configured for an app.
4. Strip personal identifiers, wallet data, bearer tokens, OTPs, payloads and network secrets from input evidence.
5. Evaluate sanitized snapshot using the bundled script; verify incidents against provider logs rather than assuming an offline report is live monitoring.
6. Document incident timeline, impact, mitigation, recovery checks and a safe no-retry rule for ambiguous financial sends.

## Bundled offline checker

From a local workspace with Python 3.11+:

```bash
python scripts/incident_triage.py --input /path/to/health-snapshot.json
```

The checker prints JSON and returns exit code `0` only when all specified evidence gates pass; `2` means blocked or incomplete evidence. It **never runs live external actions**. Its `passed` flag only evaluates supplied evidence.

## Required safety boundaries

- Unrelated applications and their tenants are separate projects: never mix their secrets, wallet sessions, databases, source branches, test credentials or baselines.
- Default to mock/sandbox and read-only analysis. Live funds, public publishing, altering production permissions, destructive tests, network load, or privileged actions need separate explicit approval.
- Never represent an offline synthetic-fixture success as production readiness, security certification, APK device validation, or deployment completion.
- Preserve the currently approved release baseline for each project. For production releases, also invoke `production-release-gatekeeper` and `verification-before-completion`.

## Reference

Read `references/telemetry-and-incident-handbook.md` for scenario-specific controls and acceptance criteria.
