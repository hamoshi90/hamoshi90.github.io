# Production Monitoring & Incident Response: field guide

Assess sanitized snapshots of service health, request error rate, p95 latency and last-success freshness; produce evidence-based severity without contacting live services.

## Acceptance criteria

- Resolve which independent project and deployment are affected; identify owned service names and approved telemetry channels.
- Define health signals, thresholds, SLOs, alert ownership, deduplication, incident severity and rollback actions before production.
- Use PostHog if connected for opt-in product analytics, errors and feature rollout events; use Datadog if separately connected for service metrics/traces, never assume either is configured for an app.
- Strip personal identifiers, wallet data, bearer tokens, OTPs, payloads and network secrets from input evidence.
- Evaluate sanitized snapshot using the bundled script; verify incidents against provider logs rather than assuming an offline report is live monitoring.
- Document incident timeline, impact, mitigation, recovery checks and a safe no-retry rule for ambiguous financial sends.

## Limitations and caveats

Do not create notifications, dashboards, monitors or production alerts without request and scoped access. Metrics may be absent until SDKs/exporters are installed. PostHog is not a replacement for infrastructure APM.

## Evidence classification

- `verified`: directly observed tool output, test log, or execution trace on the named environment.
- `self-reported`: supplied JSON/attestation whose truth was not independently checked.
- `planned`: design, documentation, or example workflow that has not been deployed.

Do not promote `self-reported` or `planned` to `verified`.
