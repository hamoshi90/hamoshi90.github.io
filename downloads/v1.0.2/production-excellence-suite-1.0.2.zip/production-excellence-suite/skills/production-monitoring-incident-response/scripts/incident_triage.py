"""Review sanitized, offline service-health snapshots; never contacts endpoints."""
import argparse
import json
import math
import re


def number(x, minimum=0, maximum=float('inf')):
    return type(x) in (int, float) and math.isfinite(x) and minimum <= x <= maximum


def evaluate(data):
    issues = []
    if not isinstance(data, dict) or not isinstance(data.get('services'), list) or not data['services']:
        return {'passed': False, 'severity': 'unknown', 'alerts': ['No service health evidence.']}
    any_critical = False
    for i, service in enumerate(data['services']):
        tag = f'service_{i+1}'
        if not isinstance(service, dict):
            issues.append(tag + ': invalid service record')
            continue
        if service.get('healthy') is not True:
            issues.append(tag + ': unhealthy/unknown service')
            any_critical = True
        limits = service.get('limits')
        if not isinstance(limits, dict):
            issues.append(tag + ': missing limits')
            continue
        checks = [('error_rate', 'max_error_rate', 1), ('p95_ms', 'max_p95_ms', float('inf')),
                  ('last_success_seconds', 'max_last_success_seconds', float('inf'))]
        for name, bound, upper in checks:
            observed = service.get(name)
            maximum = limits.get(bound)
            if not number(observed, maximum=upper) or not number(maximum, maximum=upper):
                issues.append(tag + ': missing/invalid ' + name + ' or threshold')
            elif observed > maximum:
                issues.append(tag + ': exceeded ' + name + ' threshold')
                if name == 'last_success_seconds':
                    any_critical = True
    return {'passed': not issues, 'severity': 'critical' if any_critical else 'warning' if issues else 'ok',
            'services_checked': len(data['services']), 'alerts': issues,
            'note': 'Evidence-only triage. No live monitoring or alerts created.'}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', required=True)
    args = p.parse_args()
    try:
        with open(args.input, encoding='utf-8') as f:
            result = evaluate(json.load(f))
    except (OSError, ValueError, TypeError):
        result = {'passed': False, 'severity': 'unknown', 'alerts': ['Unreadable evidence.']}
    print(json.dumps(result, sort_keys=True))
    raise SystemExit(0 if result['passed'] else 2)


if __name__ == '__main__':
    main()
