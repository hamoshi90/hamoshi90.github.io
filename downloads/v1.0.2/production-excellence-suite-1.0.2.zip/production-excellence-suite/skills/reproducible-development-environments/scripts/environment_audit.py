"""Fail-closed offline audit of structured environment reproducibility evidence."""
import argparse
import json
import re


def pinned(image):
    if not isinstance(image, str) or not image.strip():
        return False
    if re.search(r'@sha256:[a-fA-F0-9]{64}$', image):
        return True
    if ':' not in image.rsplit('/', 1)[-1]:
        return False
    tag = image.rsplit(':', 1)[-1].lower()
    return tag not in ('latest', 'stable', 'edge', 'main', 'dev', 'master', '')


def evaluate(data):
    issues = []
    if not isinstance(data, dict):
        return {'passed': False, 'issues': ['Invalid environment evidence.']}
    services = data.get('services')
    if not isinstance(services, dict) or not services:
        issues.append('No container service evidence.')
        services = {}
    for service in services.values():
        if not isinstance(service, dict):
            issues.append('Invalid service metadata.')
            continue
        if not pinned(service.get('image')):
            issues.append('Unpinned or floating service image.')
        if service.get('healthcheck') is not True:
            issues.append('Missing service healthcheck evidence.')
        if service.get('uses_plaintext_secrets') is not False:
            issues.append('Plaintext secrets not ruled out.')
    locks = data.get('lockfiles')
    if not isinstance(locks, list) or not locks or not all(isinstance(v, str) and v.strip() for v in locks):
        issues.append('Missing dependency lockfile evidence.')
    if data.get('env_example') is not True:
        issues.append('Missing non-secret environment template.')
    if data.get('tests_reproducible') is not True:
        issues.append('Clean environment test run not attested.')
    if data.get('committed_real_secrets') is not False:
        issues.append('Committed credential exposure not ruled out.')
    return {'passed': not issues, 'service_count': len(services), 'issues': sorted(set(issues)),
            'note': 'Evidence review; does not run Docker, inspect actual images or contact a service.'}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', required=True)
    args = p.parse_args()
    try:
        with open(args.input, encoding='utf-8') as f:
            result = evaluate(json.load(f))
    except (OSError, ValueError, TypeError):
        result = {'passed': False, 'issues': ['Unreadable environment evidence.']}
    print(json.dumps(result, sort_keys=True))
    raise SystemExit(0 if result['passed'] else 2)


if __name__ == '__main__':
    main()
