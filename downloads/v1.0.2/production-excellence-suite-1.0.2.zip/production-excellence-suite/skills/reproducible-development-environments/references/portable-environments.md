# Reproducible Development Environments: field guide

Audit structured evidence for pinned container images, healthchecks, lockfiles, non-secret env templates and repeatable clean-environment test runs.

## Acceptance criteria

- Identify target project, approved baseline, platform, local runtime and PostgreSQL availability; do not assume Docker or database software is installed.
- Specify isolated project service names, databases, users, test data and volumes; enforce unique environment namespace per project.
- Use pinned container image versions/digests, dependency locks, reproducible seed data and healthchecks; keep real secrets out of Git and ZIP bundles.
- Copy and adapt only the bundled opt-in Compose development template. It starts a LOCAL database when manually run and is not a production deployment.
- Collect sanitized evidence JSON and run offline environment auditor; verify actual clean build and container health separately on the target system.
- Preserve existing configurations until the user authorizes changes and a rollback strategy exists.

## Limitations and caveats

No container is started automatically. The example PostgreSQL service is local-loopback only, not intended for public exposure; configure secrets securely.

## Evidence classification

- `verified`: directly observed tool output, test log, or execution trace on the named environment.
- `self-reported`: supplied JSON/attestation whose truth was not independently checked.
- `planned`: design, documentation, or example workflow that has not been deployed.

Do not promote `self-reported` or `planned` to `verified`.
