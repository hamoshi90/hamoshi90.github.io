---
name: reproducible-development-environments
description: "Use when preparing Docker Compose dev/staging, Windows setup, PostgreSQL testing, dependency lockfiles, reproducible builds, non-secret env templates or offline development environments."
---

# Reproducible Development Environments

Audit structured evidence for pinned container images, healthchecks, lockfiles, non-secret env templates and repeatable clean-environment test runs.

## Evidence-first workflow

1. Identify target project, approved baseline, platform, local runtime and PostgreSQL availability; do not assume Docker or database software is installed.
2. Specify isolated project service names, databases, users, test data and volumes; enforce unique environment namespace per project.
3. Use pinned container image versions/digests, dependency locks, reproducible seed data and healthchecks; keep real secrets out of Git and ZIP bundles.
4. Copy and adapt only the bundled opt-in Compose development template. It starts a LOCAL database when manually run and is not a production deployment.
5. Collect sanitized evidence JSON and run offline environment auditor; verify actual clean build and container health separately on the target system.
6. Preserve existing configurations until the user authorizes changes and a rollback strategy exists.

## Bundled offline checker

From a local workspace with Python 3.11+:

```bash
python scripts/environment_audit.py --input /path/to/environment-evidence.json
```

The checker prints JSON and returns exit code `0` only when all specified evidence gates pass; `2` means blocked or incomplete evidence. It **never runs live external actions**. Its `passed` flag only evaluates supplied evidence.

## Required safety boundaries

- Unrelated applications and their tenants are separate projects: never mix their secrets, wallet sessions, databases, source branches, test credentials or baselines.
- Default to mock/sandbox and read-only analysis. Live funds, public publishing, altering production permissions, destructive tests, network load, or privileged actions need separate explicit approval.
- Never represent an offline synthetic-fixture success as production readiness, security certification, APK device validation, or deployment completion.
- Preserve the currently approved release baseline for each project. For production releases, also invoke `production-release-gatekeeper` and `verification-before-completion`.

## Reference

Read `references/portable-environments.md` for scenario-specific controls and acceptance criteria.
