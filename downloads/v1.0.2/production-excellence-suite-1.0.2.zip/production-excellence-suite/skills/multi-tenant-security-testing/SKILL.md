---
name: multi-tenant-security-testing
description: "Use when testing tenant isolation, horizontal IDOR, owner and user roles, privilege escalation, financial wallet separation, cross-tenant queries or multiuser access policies."
---

# Multi-Tenant Security Testing

Fail-closed review of sanitized negative-test outcomes covering cross-tenant read/write/list and user-to-owner/admin privilege elevation.

## Evidence-first workflow

1. Map exact users, owners, tenants, wallet ownership, resource identifiers, role changes and service boundaries; do not reuse credentials across projects.
2. Construct isolated synthetic accounts and resources, preserving the exact allowed owner/user space-switching rules.
3. Test cross-tenant read/write/list/delete/transfer denial, filtering of collection endpoints and resource IDs, and negative role-elevation paths.
4. Collect sanitized actor-tenant/resource-tenant/operation/expected-decision observations only; do not copy personal or financial IDs.
5. Run offline case auditor; it checks coverage and denies, but cannot prove real API enforcement. Test actual endpoints in owned isolated staging if authorized.
6. Require independent code review of server-side authorization and data scoping before release, even when Android UI hides owner screens.

## Bundled offline checker

From a local workspace with Python 3.11+:

```bash
python scripts/tenant_isolation_audit.py --input /path/to/tenant-access-tests.json
```

The checker prints JSON and returns exit code `0` only when all specified evidence gates pass; `2` means blocked or incomplete evidence. It **never runs live external actions**. Its `passed` flag only evaluates supplied evidence.

## Required safety boundaries

- Unrelated applications and their tenants are separate projects: never mix their secrets, wallet sessions, databases, source branches, test credentials or baselines.
- Default to mock/sandbox and read-only analysis. Live funds, public publishing, altering production permissions, destructive tests, network load, or privileged actions need separate explicit approval.
- Never represent an offline synthetic-fixture success as production readiness, security certification, APK device validation, or deployment completion.
- Preserve the currently approved release baseline for each project. For production releases, also invoke `production-release-gatekeeper` and `verification-before-completion`.

## Reference

Read `references/tenant-threat-model.md` for scenario-specific controls and acceptance criteria.
