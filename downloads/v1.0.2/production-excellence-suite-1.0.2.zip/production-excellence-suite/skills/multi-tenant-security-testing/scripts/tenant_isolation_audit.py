"""Check sanitized tenant-isolation test evidence for cross-tenant and role leaks."""
import argparse
import json

ROLE_RANK = {'user': 0, 'owner': 1, 'admin': 2}


def evaluate(data):
    issues = []
    if not isinstance(data, dict):
        return {'passed': False, 'issues': ['Missing isolation test evidence.']}
    required = data.get('required_operations')
    cases = data.get('cases')
    if not isinstance(required, list) or not required or any(x not in ('read', 'write', 'list', 'delete', 'transfer') for x in required):
        issues.append('Missing or invalid required cross-tenant operations.')
        required = []
    if not isinstance(cases, list) or not cases:
        issues.append('No isolation test cases supplied.')
        cases = []
    covered = set()
    privilege_covered = False
    for case in cases:
        if not isinstance(case, dict):
            issues.append('Invalid isolation case.')
            continue
        a, b = case.get('actor_tenant'), case.get('resource_tenant')
        actor_role, required_role = case.get('actor_role'), case.get('requires_role')
        decision, operation = case.get('decision'), case.get('operation')
        if not all(isinstance(v, str) and v for v in (a, b, actor_role, required_role, decision, operation)) or decision not in ('allow', 'deny'):
            issues.append('Incomplete isolation test case.')
            continue
        if a != b:
            covered.add(operation)
            if decision != 'deny':
                issues.append('Cross-tenant access permitted in test evidence.')
        if actor_role not in ROLE_RANK or required_role not in ROLE_RANK:
            issues.append('Unknown role mapping.')
        elif ROLE_RANK[actor_role] < ROLE_RANK[required_role]:
            privilege_covered = True
            if decision != 'deny':
                issues.append('Privilege escalation permitted in test evidence.')
    if set(required) - covered:
        issues.append('Required cross-tenant operations lack test coverage.')
    if not privilege_covered:
        issues.append('No privilege-escalation negative case supplied.')
    return {'passed': not issues, 'test_cases': len(cases), 'cross_tenant_operations_covered': sorted(covered),
            'issues': sorted(set(issues)),
            'note': 'Offline test-case assessment; verify actual API enforcement with isolated test accounts.'}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', required=True)
    args = p.parse_args()
    try:
        with open(args.input, encoding='utf-8') as f:
            result = evaluate(json.load(f))
    except (OSError, ValueError, TypeError):
        result = {'passed': False, 'issues': ['Unreadable isolation evidence.']}
    print(json.dumps(result, sort_keys=True))
    raise SystemExit(0 if result['passed'] else 2)


if __name__ == '__main__':
    main()
