# Multi-Tenant Security Testing: field guide

Fail-closed review of sanitized negative-test outcomes covering cross-tenant read/write/list and user-to-owner/admin privilege elevation.

## Acceptance criteria

- Map exact users, owners, tenants, wallet ownership, resource identifiers, role changes and service boundaries; do not reuse credentials across projects.
- Construct isolated synthetic accounts and resources, preserving the exact allowed owner/user space-switching rules.
- Test cross-tenant read/write/list/delete/transfer denial, filtering of collection endpoints and resource IDs, and negative role-elevation paths.
- Collect sanitized actor-tenant/resource-tenant/operation/expected-decision observations only; do not copy personal or financial IDs.
- Run offline case auditor; it checks coverage and denies, but cannot prove real API enforcement. Test actual endpoints in owned isolated staging if authorized.
- Require independent code review of server-side authorization and data scoping before release, even when Android UI hides owner screens.

## Limitations and caveats

No real account probing, unsafe enumeration, or access to third-party tenants. Role rank mapping is user < owner < admin for this test harness only; customize to actual policy.

## Evidence classification

- `verified`: directly observed tool output, test log, or execution trace on the named environment.
- `self-reported`: supplied JSON/attestation whose truth was not independently checked.
- `planned`: design, documentation, or example workflow that has not been deployed.

Do not promote `self-reported` or `planned` to `verified`.
