# Project Dev Guardian — 1.0.2 Public Submission Candidate

Developer: Ali Mohammad (علي محمد)
License: Apache License, Version 2.0 for the first-party source covered by the license.

Project Dev Guardian is a skills-only plugin for read-only code and archive inspection, structured project-review planning, baseline preservation, and evidence-backed reporting.

There is no bundled MCP server, hosted API, login, payment integration, commerce or guaranteed local execution environment. Optional third-party tools referenced in documentation are not bundled and keep their own licensing terms.

Use the bundled `skills/project-dev-guardian/scripts/preflight.py` only on source that you are authorized to inspect. It accepts a ZIP or local folder and emits a JSON report; it does not write to the scanned source. The scanner is heuristic, does not run project files, and is not a substitute for full security review or runtime testing.

Publisher homepage: https://hamoshi90.github.io/tools/project-dev-guardian/
Support: https://hamoshi90.github.io/support/
Privacy: https://hamoshi90.github.io/tools/project-dev-guardian/privacy/
Terms: https://hamoshi90.github.io/tools/project-dev-guardian/terms/

**Status:** Package candidate for public submission. Do not claim the plugin has passed directory review or is publicly installed until the directory confirms it.
