# Database inspection and migration guide

Read-only SQLite health check:

```shell
python scripts/sqlite_readonly_check.py /path/to/isolated_snapshot.sqlite
```

Returns `status: pass` when SQLite `PRAGMA quick_check` reports `ok` and `PRAGMA foreign_key_check` finds no violating rows. Reports violation count only; it does NOT show sensitive row contents, prove application correctness or test backup restoration. It reads only and imposes a 1GB default input cap; change with `--max-bytes` on explicit review.

Migration acceptance checklist:
- Approve baseline DB version, migration ordering and downgrade/rollback capabilities.
- Verify working encrypted backups and restore on separate instance; retain chain of custody and checksum.
- Test valid/invalid foreign keys, owner/tenant separation, unique idempotency keys, transaction atomicity, concurrent writes and high-volume reconciliation.
- Use `Decimal` or fixed-scale integers for money, never unsafe floating-point settlement calculations.
- Compare schema and data checksums before/after in test clone without exposing records.
- For PostgreSQL: use official dump/restore tools and test transaction isolation in an authorized test environment; never presume a PostgreSQL instance is installed because the skill exists.
