---
name: database-integrity-migration
description: Check SQLite and PostgreSQL data-integrity and migration safety for multiuser apps, schema upgrades, backup restore, foreign key checks, locking, concurrency and downgrade plans. Use when the user changes database schemas, migrates SQLite to PostgreSQL, reports corrupted DB or lost records, updates credentials and session storage, diagnoses duplicate rows, or prepares production database release for unrelated customer projects.
---

# Database Integrity & Migration

Evaluate DB risks before any migration. Default to read-only inspection on a **copy/snapshot**, never production mutation.

## Procedure
1. Identify project, engine/version, schema migration version, authoritative dataset, approved baseline, size, transaction isolation, and whether the source is live. Keep each project's files and secrets isolated.
2. Back up and independently validate restore on an isolated database first; verify ownership/tenant foreign keys, uniqueness, idempotency records, monetary numeric precision, indexes, locking behavior, audit trail retention and migration ordering.
3. For an accessible SQLite file, prefer copied snapshot and run `python scripts/sqlite_readonly_check.py /path/to/copy.sqlite`. It opens `mode=ro`, performs `PRAGMA quick_check` and `PRAGMA foreign_key_check` and prints no row contents. This is not a migration or a full recovery proof.
4. For PostgreSQL, inspect SQL and migration plans offline; when an authorized test DB is available run read-only catalog queries, EXPLAIN without ANALYZE as appropriate, and migration dry-runs on disposable clones. Never execute migrations or schema-changing SQL on production without explicit permission.
5. Run concurrency tests in a disposable environment: simultaneous balances, duplicate operation IDs, long-running transactions, restore/cutover checks and migration rollback. Distinguish SQLite semantics from PostgreSQL semantics.
6. Establish pre/post record counts, referential integrity, expected schema fingerprint, compatibility with app version, measured downtime and a tested rollback plan. Block promotion if verification missing or corruption detected.
7. Report exact commands/tests that ran, results, data gaps and irreversible risks. Never include credentials, financial ledger rows or user data in reports.

See [Database inspection and migration guide](references/database-migration-guide.md).
