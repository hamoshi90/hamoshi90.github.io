#!/usr/bin/env python3
"""Read-only SQLite file checks; does not run migrations or reveal row contents."""
import argparse
import json
import sqlite3
from pathlib import Path


def audit(db_path, max_bytes=1_000_000_000):
    path = Path(db_path)
    if not path.is_file():
        raise ValueError("Database path must be an existing regular file")
    if path.stat().st_size > max_bytes:
        raise ValueError("Database exceeds configured safety size limit")
    uri = path.resolve().as_uri() + "?mode=ro"
    report = {"status": "blocked", "mode": "sqlite_read_only", "checks": {}, "database_bytes": path.stat().st_size}
    conn = sqlite3.connect(uri, uri=True, timeout=2.0)
    try:
        conn.execute("PRAGMA query_only=ON")
        quick_check = conn.execute("PRAGMA quick_check").fetchone()
        report["checks"]["quick_check"] = bool(quick_check and quick_check[0] == "ok")
        fk_count = 0
        for _ in conn.execute("PRAGMA foreign_key_check"):
            fk_count += 1
        report["checks"]["foreign_key_violations"] = fk_count
        report["checks"]["schema_objects"] = conn.execute(
            "SELECT COUNT(*) FROM sqlite_master WHERE type IN ('table','index','view','trigger')"
        ).fetchone()[0]
        report["status"] = "pass" if report["checks"]["quick_check"] and fk_count == 0 else "blocked"
        report["warning"] = "snapshot_consistency_and_restore_tests_are_separate_requirements"
    finally:
        conn.close()
    return report


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("database", type=Path)
    p.add_argument("--max-bytes", type=int, default=1_000_000_000)
    a = p.parse_args()
    try:
        if a.max_bytes < 1:
            raise ValueError("Invalid max-bytes")
        r = audit(a.database, a.max_bytes)
    except (OSError, ValueError, sqlite3.DatabaseError) as exc:
        print(json.dumps({"status": "error", "error_type": type(exc).__name__}))
        return 2
    print(json.dumps(r, indent=2))
    return 0 if r["status"] == "pass" else 2


if __name__ == "__main__":
    raise SystemExit(main())
