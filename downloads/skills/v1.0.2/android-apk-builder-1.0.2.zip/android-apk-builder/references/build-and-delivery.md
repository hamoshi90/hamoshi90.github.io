# Android APK build and delivery guidelines

## Build prerequisites
- Java compatible with project's Android Gradle Plugin; check actual project before choosing version (JDK 17 is common for AGP 8, not universal).
- Android SDK/platforms/build-tools, configured through `ANDROID_HOME` or `ANDROID_SDK_ROOT` and Android SDK licensing where required.
- Repository Gradle Wrapper (`gradlew` and `gradle/wrapper/gradle-wrapper.jar`) with correct AGP/Gradle versions, and ability to download dependencies, or a ready cached build toolchain.
- Flutter apps additionally need a compatible Flutter and Dart SDK; React Native apps need their JavaScript dependencies installed before native Gradle tasks.
- No Android SDK means local compiling is blocked. A GitHub Actions runner (or properly provisioned local builder) can provide these tools, but requires access to the Android source repository and build workflow.

## Native Gradle and Kotlin
- `./gradlew :app:testDebugUnitTest :app:assembleDebug` is a representative command; adapt modules/flavors and test task names.
- Debug APK normally lands under `app/build/outputs/apk/debug/app-debug.apk`. It is signed with a **debug key** and suitable for sideloaded testing, not Play distribution.
- Android release builds frequently output an unsigned APK without correctly configured `signingConfigs`. The `release` build label does not prove correct release signing. Verify via SDK `apksigner verify --print-certs --verbose` and compare the certificate SHA-256 digest to the expected signer.

## Flutter
- `flutter test` then `flutter build apk --debug` for testing, or `flutter build apk --release` for release (requires secure signing configuration and explicit user request). Test outputs generally under `build/app/outputs/flutter-apk/`.
- `flutter build apk --split-per-abi` may produce per-ABI APKs; an ABI-mismatched APK may not install. Prefer a compatible arm64-v8a binary for arm64 devices, otherwise an appropriate universal APK.

## GitHub Actions route
- Use a **private or user-authorized** repository with a Gradle/Flutter project, then add `references/github-actions-gradle.yml` under `.github/workflows/build-apk-debug.yml` after review. This sample supports the common Gradle Android app module. Adapt JDK version and modules to the real project.
- Trigger the workflow manually (`workflow_dispatch`), inspect logs, download the GitHub Actions artifact ZIP containing APK(s), extract in an isolated working directory, verify using SDK `apksigner`, and only then deliver a real file link.
- GitHub Actions artifacts are ZIP containers; a workflow success does not prove device installation, signature, absence of malware, or compatibility.
- Do not expose production signing keys to pull requests from forks or untrusted code. Use encrypted secrets or a trusted signing service under user control for production releases. Never upload keys to ChatGPT messages.

## Delivery checklist
1. Source commit SHA or uploaded ZIP SHA-256 and project identity recorded; do not mix projects.
2. Build command, build variant, test suite results and actual output paths recorded.
3. AndroidManifest.xml and code present in APK ZIP; no path traversal or ZIP corruption.
4. `apksigner verify` succeeded; for release, signer certificate fingerprint matches expected value.
5. APK SHA-256 and byte size recorded. Add versionName/versionCode/minSdk/packageName if inspected via trustworthy Android SDK tools.
6. Verify app has not been published or installed by mistake; device smoke tests described only if actually executed.
7. Exact file exists in active runtime before linking. If external artifact download cannot be imported, explain limitation rather than invent a sandbox link.

## Install on Android
- Open downloaded `.apk` in device Downloads; grant the Android system's per-source installation permission if prompted and if the file is trusted.
- If replacing an installed app signed with a different key, Android may reject update; avoid suggesting uninstall without explaining potential loss of app data. Confirm package ID and signing lineage for updates.

## Official references
- https://developer.android.com/build/building-cmdline
- https://developer.android.com/studio/publish/app-signing
- https://docs.github.com/en/actions/tutorials/build-and-test-code/java-with-gradle
- https://docs.flutter.dev/deployment/android
