# android-apk-builder — standalone skill 1.0.2

android-apk-builder is a standalone skill extracted without code changes from Ali Mohammad's Android APK Builder v1.0.2 source release. The included Python scripts are optional and do not provide a hosted service, live finance access, or deployment. See README and LICENSE.

Publisher: Ali Mohammad (علي محمد).
Source suite: Android APK Builder v1.0.2.
Source bundle SHA-256: `861fa090fb2b18a2bc995cef094869cfc5b3fa9479e2f022884818e8e2f6ff2d`.
Website: https://hamoshi90.github.io/tools/android-apk-builder/
Support: https://hamoshi90.github.io/support/

Contains one SKILL.md plus related optional resources. Upload as a single skill only if your ChatGPT account and workspace support skill uploads. Alternatively review the text and scripts locally. Uploading a ZIP does not imply an official OpenAI Plugin Directory listing or security certification.

License: Apache License 2.0 for first-party material the publisher is authorized to license. Check NOTICE.
