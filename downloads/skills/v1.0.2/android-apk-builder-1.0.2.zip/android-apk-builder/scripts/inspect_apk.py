#!/usr/bin/env python3
"""Inspect a compiled Android APK; never confuse ZIP integrity with signing verification."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import zipfile

MAX_ENTRIES = 200_000
MAX_INFLATED_BYTES = 4 * 1024**3
FINGERPRINT_PATTERN = re.compile(r"Signer #\d+ certificate SHA-256 digest:\s*([\da-fA-F:]+)")


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fd:
        while block := fd.read(1024 * 1024):
            h.update(block)
    return h.hexdigest()


def _normalized_hex(value: str) -> str:
    result = value.strip().replace(":", "").replace(" ", "").lower()
    if not re.fullmatch(r"[0-9a-f]{64}", result):
        raise ValueError("SHA-256 certificate fingerprint must be 64 hexadecimal digits")
    return result


def inspect_apk(path: Path, expected_cert_sha256: str | None = None) -> dict:
    path = Path(path).resolve()
    report = {
        "path": str(path),
        "exists": path.is_file(),
        "bytes": 0,
        "sha256": None,
        "apk_zip_valid": False,
        "has_android_manifest": False,
        "contains_executable_code": False,
        "signature": "not_checked",
        "signer_cert_sha256": [],
        "expected_signer_matches": None,
        "errors": [],
        "warnings": [],
    }
    if not report["exists"]:
        report["errors"].append("APK file not found")
        return report
    if path.suffix.lower() != ".apk":
        report["errors"].append("File extension must be .apk")
        return report
    report["bytes"] = path.stat().st_size
    report["sha256"] = digest(path)
    try:
        with zipfile.ZipFile(path) as zf:
            entries = zf.infolist()
            if not entries or len(entries) > MAX_ENTRIES:
                report["errors"].append("Unsafe ZIP entry count")
                return report
            names = [i.filename for i in entries]
            if len(names) != len(set(names)):
                report["errors"].append("Duplicate ZIP member names")
                return report
            inflated = sum(i.file_size for i in entries)
            if inflated > MAX_INFLATED_BYTES:
                report["errors"].append("Uncompressed APK contents exceed safe inspection threshold")
                return report
            for item in entries:
                filename = item.filename.replace("\\", "/")
                if filename.startswith("/") or any(p == ".." for p in filename.split("/")):
                    report["errors"].append("Unsafe ZIP path detected")
                    return report
                if item.flag_bits & 1:
                    report["errors"].append("Encrypted ZIP member; cannot inspect")
                    return report
            bad_file = zf.testzip()
            if bad_file is not None:
                report["errors"].append("CRC failure in a ZIP member")
                return report
            report["has_android_manifest"] = "AndroidManifest.xml" in names
            report["contains_executable_code"] = any(
                re.fullmatch(r"classes\d*\.dex", name) or
                (name.startswith("lib/") and name.endswith(".so"))
                for name in names
            )
            report["apk_zip_valid"] = True
            if not report["has_android_manifest"]:
                report["errors"].append("AndroidManifest.xml missing")
            if not report["contains_executable_code"]:
                report["warnings"].append("No DEX or native library detected; inspect unusual app content")
    except (zipfile.BadZipFile, OSError, RuntimeError, ValueError) as exc:
        report["errors"].append(f"APK ZIP inspection failed: {type(exc).__name__}")
        return report
    if report["errors"]:
        return report
    signer = shutil.which("apksigner")
    if not signer:
        android_home = os.getenv("ANDROID_HOME") or os.getenv("ANDROID_SDK_ROOT")
        if android_home:
            candidate = sorted((Path(android_home) / "build-tools").glob("*/apksigner"))
            if candidate:
                signer = str(candidate[-1])
    if not signer:
        report["signature"] = "not_verified_apksigner_missing"
        report["warnings"].append("Android SDK apksigner unavailable; signature is not verified")
        return report
    try:
        out = subprocess.run([signer, "verify", "--verbose", "--print-certs", str(path)],
                             capture_output=True, text=True, timeout=45, check=False)
    except (OSError, subprocess.TimeoutExpired):
        report["signature"] = "verification_failed"
        report["errors"].append("apksigner could not complete signature verification")
        return report
    if out.returncode != 0:
        report["signature"] = "verification_failed"
        report["errors"].append("apksigner cryptographic verification failed")
        return report
    report["signature"] = "verified"
    report["signer_cert_sha256"] = [_normalized_hex(s) for s in FINGERPRINT_PATTERN.findall(out.stdout)]
    if expected_cert_sha256 is not None:
        expected = _normalized_hex(expected_cert_sha256)
        report["expected_signer_matches"] = expected in report["signer_cert_sha256"]
        if not report["expected_signer_matches"]:
            report["errors"].append("Release signer certificate fingerprint does not match expected value")
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("apk", type=Path)
    parser.add_argument("--expected-cert-sha256", help="Expected release signing certificate SHA-256 digest")
    parser.add_argument("--require-signed", action="store_true", help="Fail if cryptographic signature is not verified")
    parser.add_argument("--json-output", type=Path, help="Write machine-readable audit JSON")
    args = parser.parse_args()
    try:
        result = inspect_apk(args.apk, args.expected_cert_sha256)
    except ValueError as exc:
        parser.error(str(exc))
    if args.require_signed and result["signature"] != "verified":
        result["errors"].append("Installable APK cannot be confirmed without valid cryptographic signature")
    payload = json.dumps(result, ensure_ascii=False, indent=2)
    print(payload)
    if args.json_output:
        args.json_output.parent.mkdir(parents=True, exist_ok=True)
        args.json_output.write_text(payload + "\n", encoding="utf-8")
    return 1 if result["errors"] else 0


if __name__ == "__main__":
    sys.exit(main())
