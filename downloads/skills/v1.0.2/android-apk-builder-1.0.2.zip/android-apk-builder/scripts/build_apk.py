#!/usr/bin/env python3
"""Build an authorized Android project's APK with an installed SDK/Flutter SDK."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

from inspect_apk import inspect_apk


def pick_project(project: Path) -> tuple[str, Path]:
    if (project / "pubspec.yaml").exists() and (project / "android").is_dir():
        return "flutter", project
    if (project / "gradlew").is_file():
        return "gradle", project
    if (project / "android" / "gradlew").is_file():
        return "gradle", project / "android"
    raise ValueError("No Flutter app or Gradle Wrapper found; supply an Android project")


def has_android_sdk() -> bool:
    home = os.getenv("ANDROID_HOME") or os.getenv("ANDROID_SDK_ROOT")
    return bool(home and Path(home).is_dir())


def build(project: Path, output_dir: Path, release: bool, module: str,
          expected_cert_sha256: str | None, skip_tests: bool = False) -> list[dict]:
    project = project.resolve()
    if not project.is_dir():
        raise ValueError("Project directory does not exist")
    if release and not expected_cert_sha256:
        raise ValueError("Release builds require --expected-cert-sha256 and configured signing")
    kind, build_root = pick_project(project)
    if not has_android_sdk():
        raise RuntimeError("Android SDK missing; use an authorized GitHub Actions runner or configure ANDROID_HOME")
    if kind == "flutter":
        if not shutil.which("flutter"):
            raise RuntimeError("Flutter SDK missing; cannot compile Flutter APK here")
        if not skip_tests:
            subprocess.run(["flutter", "test"], cwd=build_root, check=True)
        subprocess.run(["flutter", "build", "apk", "--release" if release else "--debug"],
                       cwd=build_root, check=True)
        apk_dir = build_root / "build" / "app" / "outputs" / "flutter-apk"
    else:
        wrapper = build_root / "gradlew"
        if not wrapper.is_file() or not (build_root / "gradle" / "wrapper" / "gradle-wrapper.jar").is_file():
            raise RuntimeError("Gradle Wrapper or wrapper JAR missing; do not download unknown executables")
        if not shutil.which("java"):
            raise RuntimeError("Java runtime missing")
        if not module.startswith(":") or not all(x.isalnum() or x in "_-:" for x in module):
            raise ValueError("--module must be colon-prefixed Gradle path e.g. :app or :feature:app")
        build_type = "Release" if release else "Debug"
        tasks = ([] if skip_tests else [f"{module}:test{build_type}UnitTest"]) + [f"{module}:assemble{build_type}"]
        subprocess.run(["bash", str(wrapper), "--no-daemon", *tasks], cwd=build_root, check=True)
        module_dir = module.strip(":").replace(":", "/")
        apk_dir = build_root / module_dir / "build" / "outputs" / "apk"
    candidates = list(apk_dir.rglob("*.apk")) if apk_dir.exists() else []
    variant = "release" if release else "debug"
    candidates = [p for p in candidates if p.name.lower().endswith("-" + variant + ".apk")]
    if not candidates:
        raise RuntimeError(f"No {variant} APK was produced at expected output location")
    reports = []
    output_dir = output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    for source in candidates:
        report = inspect_apk(source, expected_cert_sha256)
        if report["errors"] or report["signature"] != "verified":
            raise RuntimeError(f"APK failed required inspection/signing verification: {source.name}, {report['errors']}, {report['signature']}")
        out_name = source.name
        target = output_dir / out_name
        if source != target:
            shutil.copy2(source, target)
        final_report = inspect_apk(target, expected_cert_sha256)
        if final_report["sha256"] != report["sha256"] or final_report["signature"] != "verified":
            raise RuntimeError("Delivery copy failed hash/signature re-verification")
        final_report.update({"variant": variant, "toolchain": kind, "project": str(project),
                             "tests": "skipped" if skip_tests else "passed_build_commands"})
        reports.append(final_report)
    return reports


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--module", default=":app")
    parser.add_argument("--release", action="store_true", help="Release requires preconfigured signing and expected cert SHA256")
    parser.add_argument("--expected-cert-sha256")
    parser.add_argument("--skip-tests", action="store_true")
    args = parser.parse_args()
    try:
        out = build(args.project, args.output_dir, args.release, args.module,
                    args.expected_cert_sha256, args.skip_tests)
    except (ValueError, RuntimeError, subprocess.CalledProcessError) as exc:
        print(json.dumps({"success": False, "error": str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 1
    print(json.dumps({"success": True, "artifacts": out}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
