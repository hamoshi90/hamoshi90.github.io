import importlib.util
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest import mock
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import inspect_apk
import build_apk


def make_test_apk(location: Path, extra=None):
    with zipfile.ZipFile(location, mode="w", compression=zipfile.ZIP_DEFLATED) as z:
        z.writestr("AndroidManifest.xml", b"\x03\x00not-real-binary-xml-test-only")
        z.writestr("classes.dex", b"dex\n035\x00fixture-not-executable")
        for name, data in extra or []:
            z.writestr(name, data)


class ApkInspectorTests(unittest.TestCase):
    def test_unsigned_zip_is_not_verified(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "sample.apk"
            make_test_apk(path)
            with mock.patch.object(inspect_apk.shutil, "which", return_value=None), \
                 mock.patch.dict(os.environ, {"ANDROID_HOME":"", "ANDROID_SDK_ROOT":""}):
                result = inspect_apk.inspect_apk(path)
            self.assertEqual(result["signature"], "not_verified_apksigner_missing")
            self.assertTrue(result["apk_zip_valid"])
            self.assertTrue(result["has_android_manifest"])
            self.assertEqual(len(result["sha256"]), 64)

    def test_invalid_zip_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "bad.apk"
            path.write_bytes(b"not a zip")
            result = inspect_apk.inspect_apk(path)
            self.assertFalse(result["apk_zip_valid"])
            self.assertTrue(result["errors"])

    def test_path_traversal_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "evil.apk"
            make_test_apk(path, [("../attack", b"unsafe")])
            result = inspect_apk.inspect_apk(path)
            self.assertTrue(any("Unsafe ZIP path" in x for x in result["errors"]))

    def test_mock_signature_expected_fingerprint(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "sample.apk"
            make_test_apk(path)
            cert = "1f" * 32
            proc = subprocess.CompletedProcess(args=[], returncode=0, stdout=f"Signer #1 certificate SHA-256 digest: {cert}\n", stderr="")
            with mock.patch.object(inspect_apk.shutil, "which", return_value="/fake/apksigner"), \
                 mock.patch.object(inspect_apk.subprocess, "run", return_value=proc):
                result = inspect_apk.inspect_apk(path, cert)
            self.assertEqual(result["signature"], "verified")
            self.assertTrue(result["expected_signer_matches"])
            self.assertFalse(result["errors"])

    def test_wrong_certificate_fails_even_if_signed(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "sample.apk"
            make_test_apk(path)
            proc = subprocess.CompletedProcess(args=[], returncode=0, stdout=f"Signer #1 certificate SHA-256 digest: {'a1'*32}\n", stderr="")
            with mock.patch.object(inspect_apk.shutil, "which", return_value="/fake/apksigner"), \
                 mock.patch.object(inspect_apk.subprocess, "run", return_value=proc):
                result = inspect_apk.inspect_apk(path, "b2"*32)
            self.assertFalse(result["expected_signer_matches"])
            self.assertTrue(result["errors"])

    def test_release_requires_expected_fingerprint(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / "gradlew").write_text("#!/bin/sh\n")
            with self.assertRaises(ValueError):
                build_apk.build(root, root / "out", True, ":app", None)

    def test_missing_sdk_fails_before_compilation(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / "gradlew").write_text("#!/bin/sh\n")
            with mock.patch.dict(os.environ, {"ANDROID_HOME":"", "ANDROID_SDK_ROOT":""}):
                with self.assertRaisesRegex(RuntimeError, "Android SDK missing"):
                    build_apk.build(root, root / "out", False, ":app", None)


if __name__ == "__main__":
    unittest.main()
