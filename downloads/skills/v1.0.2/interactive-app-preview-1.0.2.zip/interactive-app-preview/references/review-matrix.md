# Interactive app preview review matrix

## Source audit

- Record exact project/baseline/version/commit and approved theme mode.
- Keep screenshots, resources and asset hashes together; do not contaminate other projects.
- Compare source color roles **primary, accent, surface, background, text, error, selected, disabled**.
- Compare body and heading typefaces, RTL and mixed-direction numbers, density, corners, borders, elevation and iconography.

## Functional states

- Click every reachable main menu/tab/action; verify the visible destination and back navigation.
- Try valid and invalid form inputs, errors, loading, empty/history states, confirmation/cancellation and disabled buttons.
- Verify account/role switching preserves data isolation in mock state (no cross-account balances).
- Confirm no user action reaches a live financial endpoint in mock previews.
- Reopen/reset scenario and repeat for deterministic results.

## Android-specific UX checks

- Narrow screen and wide screen; status bar/notch/safe area; virtual keyboard overlap and scrolling.
- Arabic RTL alignment with explicit LTR numeric/account-address islands.
- Light/dark modes as supported by source; high contrast/focus indicators and accessibility labels.
- Compare app launcher icon/header logo and exact brand colors to original assets.
- Native device screenshot/gesture validation is a separate gate after building a debug APK; web twin alone cannot certify it.

## Evidence table per review

| Field | Example value |
|---|---|
| Project and baseline | Example local mock vX, source commit/hash |
| Design source | relative source paths, SHA-256 |
| Type of preview | Original frontend / Source-aligned web twin / Concept |
| Color roles | exact sourced hex values or unverified |
| Screens exercised | names as present in source |
| Mocked behaviors | transfer, OTP, backend, data store |
| Verified | static audit, real browser click test if run |
| Not verified | actual Android package/runtime; network |

Report failures explicitly. Do not mark "pass" for browser click or emulator tests unless those were run.
