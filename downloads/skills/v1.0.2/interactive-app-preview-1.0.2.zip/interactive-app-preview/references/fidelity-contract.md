# Interactive preview fidelity contract

## Evidence priority, strongest first

1. Current approved project/commit **running native app screenshot + assets and source design system**.
2. Current approved frontend source with original stylesheet/components/theme resources (trace hash and theme mode).
3. Component library or Figma/Canva design explicitly linked to this **same project and revision** (design intent, not necessarily current runtime).
4. User-supplied screenshots (approximate colors can be sampled, but opacity, dynamic color, font rasterization and elevation remain uncertain).
5. User textual specification; mark preview **conceptual** until a source is supplied.

Do not substitute another project's theme. Resolve source-role conflicts by following active theme and platform. Keep the approved baseline unchanged unless instructed.

## Fidelity labels

- **Original frontend preview:** Original web/WebView HTML/CSS/JS is reused, isolated and network mocked. Color/styles can be source-identical but host browser rendering may differ from WebView/Android.
- **Source-aligned interactive replica:** Reimplemented visuals and local interactions from source design evidence. Color values and named roles are grounded, but visual pixel/spacing differences may remain.
- **Screenshot-aligned concept:** Built to match provided screenshots when source is not available. Colors/spacing are inferred, not source-verified.
- **Concept demonstration:** No source or images provided. Do not claim design fidelity.

`theme_probe.py` returns `source-extracted-not-render-verified`. `audit_preview.py` distinguishes a byte-identical stylesheet from a color-overlap-only replica; even exact CSS cannot establish native-render parity.

## Rendering and UX

- Prefer actual frontend code, stylesheets, and project-local icons/logo over stock imagery.
- Match color use per semantic role, screen hierarchy, spacing, corner radius, shadows, typography, selected/disabled state, Arabic RTL and numbers (numbers and addresses may remain LTR islands).
- Support the source theme mode (light/dark), dynamic safe-area layout and device width. Never merge `values` with `values-night` silently.
- Interactive buttons, transitions, navigation, modals and forms should reproduce documented/visible behavior when possible; everything else must be clearly marked a simulation.
- Review each core screen and error/empty state. Compare screenshots side-by-side when an emulator/real device is available.
- Use safe synthetic previews with mock APIs. No real financial transfers or email OTP; separate staging authorization needed for any live integration.

## CLI example

```bash
python scripts/theme_probe.py --project /path/to/project --json-out theme_manifest.json --css-out source_tokens.css --strict
python scripts/audit_preview.py --manifest theme_manifest.json --html preview.html --stylesheet preview.css --require-rtl --offline-only --json-out audit.json
```

When original source CSS is in use:

```bash
python scripts/audit_preview.py --manifest theme_manifest.json --html preview.html --stylesheet preview.css --source-stylesheet /path/to/project/styles.css --require-rtl --offline-only --require-exact-css
```

A successful static audit proves only the checked properties; it does not test user interaction or a signed APK. Reject any visual fidelity claim that lacks an actual source pointer or screenshot comparison.
