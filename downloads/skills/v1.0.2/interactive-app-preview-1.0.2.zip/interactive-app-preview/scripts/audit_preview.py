#!/usr/bin/env python3
"""Static parity/safety audit for a read-only mobile-app preview.

Success proves source color overlap, optional stylesheet identity, explicit RTL
and no detected network calls; it never proves native Android runtime parity.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
import sys

HEX_RE=re.compile(r'(?<![a-zA-Z0-9#])#[0-9a-fA-F]{6}(?:[0-9a-fA-F]{2})?(?![a-zA-Z0-9])')
NETWORK_RE=re.compile(r'\b(?:fetch\s*\(|axios\s*\.|XMLHttpRequest\s*\(|WebSocket\s*\(|sendBeacon\s*\(|\$\.ajax\s*\(|https?://)',re.I)


def audit(manifest:dict, html:Path, stylesheet:Path, *, source_stylesheet:Path|None=None, rtl:bool=False, offline:bool=False, require_exact_css:bool=False):
    html=Path(html); stylesheet=Path(stylesheet)
    page=html.read_text(encoding='utf-8')
    css=stylesheet.read_text(encoding='utf-8')
    combined=page+'\n'+css
    original_tokens={t['value'].lower() for t in manifest.get('tokens',[])}
    found={x.lower() for x in HEX_RE.findall(combined)}
    overlap=sorted(original_tokens & found)
    issues=[]
    if not original_tokens:
        issues.append('No authenticated named source palette tokens exist')
    elif not overlap:
        issues.append('No source palette colors found in preview markup or stylesheet')
    if rtl and not (re.search(r'\bdir\s*=\s*[\'\"]rtl[\'\"]',page,re.I) or re.search(r'\bdirection\s*:\s*rtl\b',combined,re.I)):
        issues.append('RTL layout was requested but is not explicitly enabled')
    if offline and NETWORK_RE.search(combined):
        issues.append('Network-capable code detected in offline-only preview')
    exact=False
    if source_stylesheet:
        exact=hashlib.sha256(Path(source_stylesheet).read_bytes()).digest()==hashlib.sha256(stylesheet.read_bytes()).digest()
    if require_exact_css and not exact:
        issues.append('Preview stylesheet does not match the original stylesheet byte-for-byte')
    fidelity='source-stylesheet-identical' if exact else ('color-overlap-only' if overlap else 'no-color-evidence')
    return {'passed':not issues,'issues':issues,'stylesheet_fidelity':fidelity,
            'color_overlap_count':len(overlap),'matched_source_colors':overlap,
            'runtime_verified':False,
            'note':'Static checks cannot establish native screen, font rendering, touch behavior or APK fidelity.'}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--manifest',required=True)
    p.add_argument('--html',required=True)
    p.add_argument('--stylesheet',required=True)
    p.add_argument('--source-stylesheet')
    p.add_argument('--require-rtl',action='store_true')
    p.add_argument('--offline-only',action='store_true')
    p.add_argument('--require-exact-css',action='store_true')
    p.add_argument('--json-out')
    args=p.parse_args()
    try:
        manifest=json.loads(Path(args.manifest).read_text(encoding='utf-8'))
        report=audit(manifest,Path(args.html),Path(args.stylesheet),source_stylesheet=Path(args.source_stylesheet) if args.source_stylesheet else None,
                     rtl=args.require_rtl,offline=args.offline_only,require_exact_css=args.require_exact_css)
        output=json.dumps(report,ensure_ascii=False,indent=2)+'\n'
        if args.json_out:
            Path(args.json_out).write_text(output,encoding='utf-8')
        print(output)
        return 0 if report['passed'] else 2
    except (OSError,ValueError,KeyError) as e:
        print('Error: '+str(e),file=sys.stderr)
        return 2


if __name__=='__main__':
    sys.exit(main())
