#!/usr/bin/env python3
"""Read-only extraction of source-backed app theme tokens. No network or SDK required.

This tool collects design *evidence*, never establishes screenshot/native-render fidelity.
"""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

MAX_FILES = 2500
MAX_TEXT_BYTES = 750_000
IGNORED_DIRS = {'.git', 'node_modules', '.gradle', '.dart_tool', 'Pods', 'build', 'dist', 'out', '.venv', '__pycache__', '.next', 'vendor', 'coverage', 'preview', 'preview-build'}
STYLE_EXTENSIONS = {'.css', '.scss', '.sass', '.less', '.kt', '.kts', '.dart', '.xml', '.json', '.js', '.jsx', '.ts', '.tsx', '.html'}
HEX_RE = re.compile(r'(?<![\w#])#[0-9a-fA-F]{3,4}(?![\w])|(?<![\w#])#[0-9a-fA-F]{6}(?:[0-9a-fA-F]{2})?(?![\w])')
CSS_TOKEN_RE = re.compile(r'--([a-zA-Z][\w-]*)\s*:\s*(#[0-9a-fA-F]{3,4}|#[0-9a-fA-F]{6}(?:[0-9a-fA-F]{2})?)(?![0-9a-fA-F])')
NAMED_COLOR_RE = re.compile(r'[\'\"]?([\w-]+)[\'\"]?\s*[:=]\s*[\'\"](#[0-9a-fA-F]{3,4}|#[0-9a-fA-F]{6}(?:[0-9a-fA-F]{2})?)[\'\"]')
COMPOSE_RE = re.compile(r'\b(?:val|var)\s+(\w+)\s*=\s*(?:Color\()\s*0x([0-9a-fA-F]{8})\s*\)')
FLUTTER_RE = re.compile(r'\b(\w+)\s*[:=]\s*(?:const\s+)?Color\(0x([0-9a-fA-F]{8})\)')
FONT_RE = re.compile(r'font-family\s*:\s*([^;\}\n]+)', re.IGNORECASE)


def _mode(path: str):
    s = path.lower()
    if 'values-night' in s or re.search(r'(?:^|[/._-])dark(?:[/._-]|$)', s):
        return 'dark'
    return 'light-or-default'


def _normalize(value: str, argb: bool = False):
    v = value.lower().replace('0x', '#')
    if not v.startswith('#'):
        v = '#'+v
    digits = v[1:]
    if argb and len(digits)==8:
        alpha, rgb = digits[:2], digits[2:]
        return '#'+rgb if alpha == 'ff' else '#'+rgb+alpha
    if len(digits)==3:
        return '#'+''.join(ch*2 for ch in digits)
    return v


def _eligible(path: Path):
    if path.suffix.lower() not in STYLE_EXTENSIONS:
        return False
    n = path.name.lower()
    if n.startswith('preview.') or n in ('preview.css', 'preview.html'):
        return False
    if path.suffix.lower() in {'.js', '.jsx', '.ts', '.tsx', '.json'}:
        return any(tag in str(path).lower() for tag in ('theme', 'color', 'palette', 'token', 'style', 'design'))
    if path.suffix.lower() == '.xml':
        return ('color' in n or 'style' in n or 'theme' in n or 'values' in str(path).lower())
    if path.suffix.lower() in {'.kt', '.kts', '.dart'}:
        return any(tag in str(path).lower() for tag in ('theme', 'color', 'palette', 'style'))
    return True


def scan_project(project: str | Path):
    root = Path(project).resolve(strict=True)
    if not root.is_dir():
        raise ValueError('Project must be a directory containing source files')
    tokens = []
    colors = Counter()
    fonts = []
    stylesheets = []
    files_scanned = 0
    seen = set()

    def add(name, rawval, path, line=1, kind='unknown', argb=False):
        value = _normalize(rawval, argb=argb)
        if not re.fullmatch(r'#[0-9a-f]{6}(?:[0-9a-f]{2})?',value):
            return
        key = (name.lower(), value, path.as_posix(), line, kind)
        if key in seen:
            return
        seen.add(key)
        tokens.append({'name':name, 'value':value, 'source':path.as_posix(), 'line':line,
                       'kind':kind, 'mode':_mode(path.as_posix()), 'source_sha256': hashes[path]})

    hashes = {}
    for candidate in sorted(root.rglob('*')):
        if len(candidate.parts)-len(root.parts)>15:
            continue
        if any(p in IGNORED_DIRS for p in candidate.relative_to(root).parts[:-1]):
            continue
        if candidate.is_symlink() or not candidate.is_file():
            continue
        if not _eligible(candidate):
            continue
        if candidate.stat().st_size>MAX_TEXT_BYTES:
            continue
        files_scanned += 1
        if files_scanned>MAX_FILES:
            raise RuntimeError('Too many style/source files: narrow the project directory')
        rel=candidate.relative_to(root)
        raw=candidate.read_bytes()
        try:
            content=raw.decode('utf-8')
        except UnicodeDecodeError:
            continue
        hashes[rel]=hashlib.sha256(raw).hexdigest()
        ext=candidate.suffix.lower()
        # We record all palette colors as candidates, but only named source tokens
        # are suitable to attach UI roles to without designer review.
        if ext in {'.css', '.scss', '.sass', '.less', '.html', '.xml', '.kt', '.kts', '.dart', '.json', '.js', '.jsx', '.ts', '.tsx'}:
            for col in HEX_RE.findall(content):
                norm=_normalize(col)
                if re.fullmatch(r'#[0-9a-f]{6}(?:[0-9a-f]{2})?',norm):
                    colors[norm]+=1
        if ext in {'.css','.scss','.sass','.less','.html'}:
            if ext in {'.css','.scss','.sass','.less'}:
                stylesheets.append({'source':rel.as_posix(),'sha256':hashes[rel]})
            for m in CSS_TOKEN_RE.finditer(content):
                add(m.group(1),m.group(2),rel,content.count('\n',0,m.start())+1,'css-variable')
            for m in FONT_RE.finditer(content):
                fonts.append({'value':m.group(1).strip(), 'source':rel.as_posix(), 'line':content.count('\n',0,m.start())+1})
        if ext=='.xml':
            try:
                tree=ET.fromstring(content)
                for elem in tree.iter():
                    tag=elem.tag.split('}')[-1]
                    if tag in ('color','item'):
                        name=elem.attrib.get('name','')
                        value=(elem.text or '').strip()
                        if name and re.fullmatch(r'#[0-9a-fA-F]{6,8}', value):
                            add(name,value,rel,content[:content.find(value)].count('\n')+1,'android-resource',argb=(len(value)==9))
            except ET.ParseError:
                pass
        if ext in {'.kt','.kts'}:
            for m in COMPOSE_RE.finditer(content):
                add(m.group(1),'#'+m.group(2),rel,content.count('\n',0,m.start())+1,'compose-color',argb=True)
        if ext=='.dart':
            for m in FLUTTER_RE.finditer(content):
                add(m.group(1),'#'+m.group(2),rel,content.count('\n',0,m.start())+1,'flutter-color',argb=True)
        if ext in {'.js','.jsx','.ts','.tsx','.json'}:
            for m in NAMED_COLOR_RE.finditer(content):
                add(m.group(1),m.group(2),rel,content.count('\n',0,m.start())+1,'theme-object')

    tokens.sort(key=lambda t:(t['source'], t['line'], t['name']))
    by_name={}
    for t in tokens:
        by_name.setdefault((t['name'],t['mode']),set()).add(t['value'])
    conflicts=[{'name':name,'mode':mode,'values':sorted(values)} for (name,mode),values in by_name.items() if len(values)>1]
    return {'schema_version':1,'root':str(root),'evidence_level':'source-extracted-not-render-verified' if tokens else 'missing-design-evidence',
            'tokens':tokens,'discovered_colors':[{'value':key,'occurrences':count} for key,count in colors.most_common(60)],
            'fonts':fonts[:50],'stylesheets':stylesheets,'conflicts':conflicts,'files_scanned':files_scanned,
            'limitations':['Extraction is evidence of source tokens, not a guarantee of screenshot pixel parity.',
                           'Material You/dynamic Android system colors may vary at runtime.',
                           'When role definitions conflict, do not select a color without tracing the active theme.']}


def render_css(manifest: dict):
    """Export uniquely sourced tokens, never invent primary/secondary role assignments."""
    by_mode={'light-or-default':{},'dark':{}}
    conflicting={(x['name'],x['mode']) for x in manifest.get('conflicts',[])}
    for token in manifest.get('tokens',[]):
        if (token['name'],token['mode']) in conflicting:
            continue
        by_mode.setdefault(token['mode'],{})[token['name']]=token['value']
    chunks=['/* Generated from source tokens; not a substitute for the app\'s original stylesheet. */']
    for mode,selector in [('light-or-default',':root'),('dark','[data-theme="dark"]')]:
        if by_mode.get(mode):
            chunks.append(selector+' {')
            for name,value in sorted(by_mode[mode].items()):
                key=re.sub(r'[^a-z0-9-]','-',name.lower().replace('_','-')).strip('-')
                chunks.append(f'  --source-{key}: {value};')
            chunks.append('}')
    return '\n'.join(chunks)+'\n'


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--project',required=True)
    p.add_argument('--json-out')
    p.add_argument('--css-out')
    p.add_argument('--strict',action='store_true',help='Require at least one authentic named color token')
    args=p.parse_args()
    try:
        result=scan_project(args.project)
        if args.strict and not result['tokens']:
            print('BLOCKED: No named design tokens found; provide original theme files or screenshot evidence.',file=sys.stderr)
            return 2
        if args.json_out:
            Path(args.json_out).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        else:
            print(json.dumps(result,ensure_ascii=False,indent=2))
        if args.css_out:
            Path(args.css_out).write_text(render_css(result),encoding='utf-8')
        return 0
    except (ValueError, RuntimeError, OSError) as e:
        print('Error: '+str(e),file=sys.stderr)
        return 2


if __name__=='__main__':
    sys.exit(main())
