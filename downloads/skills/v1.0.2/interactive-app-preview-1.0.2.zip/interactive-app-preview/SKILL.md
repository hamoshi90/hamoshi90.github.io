---
name: interactive-app-preview
description: Use when a user wants a real-looking, interactive, source-faithful preview of an Android or web app inside ChatGPT before building APK; when checking exact app colors, typography, RTL layout, icons, dark/light themes, navigation, buttons, forms and user roles; or when revising app visual design and comparing it against existing app source/screenshots. Read actual project design assets/stylesheet/theme files first, use source-backed design tokens and preserve the current project baseline. Treat a web/native simulation as a preview, not a working APK or verified Android runtime.
---

# Interactive App Preview — source-faithful mobile previews

Create a **clickable review prototype inside the conversation**, using the **actual project's design**, not a generic ChatGPT style or an invented palette. This is a build-preview-review workflow which complements Android APK Builder, Project Dev Guardian and Engineering Quality Suite.

## Core fidelity rule

**Do not label a preview "same colors as the app" without design evidence from the exact project/version.** Match source evidence (CSS, theme resources, tokens, original icons, RTL, fonts, screen spacing, radii, typography) before drawing. Never silently substitute an attractive new design, use remembered colors from a different project, or borrow assets/secrets/sessions across unrelated projects and tenants.

If colors are unavailable from source, say **"لا تتوفر مصادر التصميم للتحقق من الألوان"**, request theme files or screenshots, and mark any guess as a provisional design—not a faithful preview. A screenshot-derived palette is estimated, not exact code-level theme evidence.

## Workflow

1. **Identify baseline:** Confirm project and approved version or exact GitHub commit. Inspect the current project's ZIP/working directory/GitHub files rather than relying on a previous description. Never change baseline or production build merely to show a preview.
2. **Inspect visual source:** Locate screens/routes/layout resources, theme files, CSS, Compose `Color.kt`/`Theme.kt`, Android `res/values/colors.xml` and `values-night`, Flutter `ThemeData`, React Native tokens, original icons, logos and fonts. Extract visual design token evidence and file hashes with `python scripts/theme_probe.py --project PROJECT --json-out theme_manifest.json --css-out source_tokens.css --strict`. Inspect actual semantic roles and resolve conflicts manually (including active light/dark mode). `source_tokens.css` is evidence, **not a substitute for original CSS**. If `--strict` finds nothing, obtain sources or screenshots; do not invent palette.
3. **Prioritize real UI reuse:**
   - **HTML/CSS/WebView app**: Copy/adapt actual frontend structure and styles into an isolated preview; reuse original stylesheet/assets and as much original UI code as safe; replace external network adapters with local fixtures. A preview may closely match the original if using the same HTML/CSS, subject to rendering platform differences.
   - **React/Vue/React Native**: Reuse source components, tokens and layout logic in a sandboxed web preview where supported; explain any native component approximations.
   - **Jetpack Compose/Android XML/Flutter**: Create an interactive **web-based visual twin** faithful to source tokens and UI hierarchy. This is NOT the native Android renderer. For pixel-level claims, request or generate an actual device/emulator screenshot, compare it to the preview and document differences.
4. **Render in this conversation when possible:** Choose the current chat client's supported embedded, interactive preview UI mechanism, including an inline app visualization when available. Keep preview app scoped to this turn/project. Preserve Arabic RTL, typography, color roles, component density, iconography, screen spacing and accessibility contrast. **Use real project CSS/fonts/icons whenever available**. If inline embedding is unavailable or too restricted for the real app, provide a working local/hosted HTML browser preview link and state the limitation rather than presenting a static picture as interactive. Do not call a generated screenshot an interactive preview.
5. **Make interaction meaningful:** Implement screen navigation, send/receive/history displays, buttons, dialogs, input validation, loading/empty/error/success states and role switching only as present in that project's source/spec. Every functional control must perform its advertised local-preview action. Test keyboard/mobile sizing and RTL before approval. If a backend is unavailable, show **"محاكاة / بيانات تجريبية"** on the preview.
6. **Finance and security:** For wallets, payment previews and account screens, use **synthetic data only** by default. No live wallet-provider sessions, passwords, bearer tokens, API calls, bank transactions, production credentials, real OTP, real money or third-party account modifications. Never move secrets between projects. Keep preview fixtures distinct from production stores. For any actual live integration, require separate authorized staging setup; do not sneak it into a visual preview.
7. **Verify and report:** Run `python scripts/audit_preview.py --manifest theme_manifest.json --html preview.html --stylesheet preview.css --require-rtl --offline-only --json-out audit.json` for an Arabic offline prototype. When original WebView CSS is byte-identical, also pass `--source-stylesheet ORIGINAL.css --require-exact-css`; otherwise report only source-color overlap. The static audit is **not** an emulator/device test; run actual browser interaction/screenshot review if tools are available. Clearly distinguish verified source color reuse, visual approximations, mocked interactions and unverified native behavior.
8. **User review before APK:** Show the preview and summarize what is interactive vs simulated; ask for visual and flow changes, reuse the modified design only after approval. When user requests building, invoke Android APK Builder; build/verify an actual signed APK before sharing a binary link. Approval of a web twin does not imply APK compilation or live deployment.

## Output contract for every preview

Present the clickable preview first (where supported), then a brief traceability report: **project/baseline; source files or screenshot reference; theme mode; exact sourced primary/background/text colors or "unverified"; screens and actions included; what is mocked; browser interaction test result; divergences from native UI; next step (revise / APK)**. Keep claims proportional to evidence; report a visual mismatch rather than hiding it.

## Source-backed example

A project has `web/assets/styles.css` containing `:root{--navy:#102a3c;--green:#18b58f;}`. Extract both values with `theme_probe.py`, reuse actual components/styles where possible, and render buttons/navigation in that palette. Do **not** assume `navy` means every background is navy or guess the app has a light-only theme. If actual CSS is reused, compare SHA-256. If the preview uses CSS rewritten from these tokens, label it a **source-color-matched reimplementation**, not a pixel-identical copy. If the user's actual source shows different values, the actual source wins over this example.

## Supporting references and tooling

- `references/fidelity-contract.md`: source hierarchy, fidelity levels and limits for native vs web UI.
- `references/review-matrix.md`: quick functional, state and Android/mobile review checklist.
- `scripts/theme_probe.py`: offline source color/typography evidence and conflict reporting; read-only.
- `scripts/audit_preview.py`: local static token parity + RTL + offline-network guard; read-only.
- `tests` in plugin root: runnable unit/regression tests for both scripts.

**Important:** This skill supplies an engineering procedure and reusable checks. It does not install Android SDK, run a native emulator by itself, open bank sessions, deploy a backend, or guarantee pixel-identical rendering without native screenshots and tests.
