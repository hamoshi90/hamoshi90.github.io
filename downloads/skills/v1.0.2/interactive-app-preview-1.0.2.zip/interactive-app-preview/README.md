# interactive-app-preview — standalone skill 1.0.2

interactive-app-preview is a standalone skill extracted without code changes from Ali Mohammad's Interactive App Preview v1.0.2 source release. The included Python scripts are optional and do not provide a hosted service, live finance access, or deployment. See README and LICENSE.

Publisher: Ali Mohammad (علي محمد).
Source suite: Interactive App Preview v1.0.2.
Source bundle SHA-256: `398132b28de5570015a434b71df49fa6d9dd5f3ee1d8204bb15dc39254b494ea`.
Website: https://hamoshi90.github.io/tools/interactive-app-preview/
Support: https://hamoshi90.github.io/support/

Contains one SKILL.md plus related optional resources. Upload as a single skill only if your ChatGPT account and workspace support skill uploads. Alternatively review the text and scripts locally. Uploading a ZIP does not imply an official OpenAI Plugin Directory listing or security certification.

License: Apache License 2.0 for first-party material the publisher is authorized to license. Check NOTICE.
