#!/usr/bin/env python3
"""Offline audit of synthetic/sanitized financial operation traces. Never sends funds."""
import argparse
import json
from pathlib import Path

TRANSITIONS = {
    "created": {"previewed", "submitted", "rejected", "canceled"},
    "previewed": {"submitted", "rejected", "canceled"},
    "submitted": {"pending", "unknown", "succeeded", "rejected"},
    "pending": {"unknown", "succeeded", "rejected"},
    "unknown": {"pending", "manual_review", "succeeded", "rejected"},
    "manual_review": {"succeeded", "rejected"},
    "succeeded": set(),
    "rejected": set(),
    "canceled": set(),
}


def audit(data):
    if not isinstance(data, dict) or not isinstance(data.get("transfers"), list):
        raise ValueError("Expected an object containing a transfers list")
    issues = []
    seen_keys = set()

    def add(index, code, severity="blocker"):
        issues.append({"transfer_index": index, "code": code, "severity": severity})

    for index, transfer in enumerate(data["transfers"]):
        if not isinstance(transfer, dict):
            add(index, "INVALID_TRANSFER")
            continue
        key = transfer.get("idempotency_key")
        if not isinstance(key, str) or not key.strip():
            add(index, "MISSING_IDEMPOTENCY_KEY")
        elif key in seen_keys:
            add(index, "IDEMPOTENCY_KEY_REUSED_ACROSS_OPERATIONS")
        else:
            seen_keys.add(key)
        events = transfer.get("events")
        if not isinstance(events, list) or not events:
            add(index, "MISSING_STATUS_EVENTS")
            continue
        statuses = []
        for event in events:
            state = event.get("status") if isinstance(event, dict) else None
            if state not in TRANSITIONS:
                add(index, "UNKNOWN_STATUS")
                state = None
            statuses.append(state)
        if statuses[0] != "created":
            add(index, "MISSING_CREATED_STATE")
        for prior, next_state in zip(statuses, statuses[1:]):
            if prior in TRANSITIONS and next_state in TRANSITIONS and next_state not in TRANSITIONS[prior]:
                add(index, "ILLEGAL_STATE_TRANSITION")
        attempts = transfer.get("send_attempts", 1)
        if isinstance(attempts, bool) or not isinstance(attempts, int) or attempts < 0:
            add(index, "INVALID_SEND_ATTEMPTS")
        elif attempts > 1:
            add(index, "MULTIPLE_SEND_ATTEMPTS_REVIEW")
        if "unknown" in statuses and attempts != 1:
            add(index, "AMBIGUOUS_OUTCOME_WITH_RESEND")
        if statuses[-1] == "succeeded" and transfer.get("receipt_verified") is not True:
            add(index, "SUCCESS_WITHOUT_VERIFIED_RECEIPT", "review")
        if statuses[-1] in ("rejected", "canceled") and transfer.get("debited") is True:
            add(index, "DECLINED_BUT_DEBIT_REPORTED")
        if statuses[-1] in ("submitted", "pending", "unknown"):
            add(index, "UNRESOLVED_OUTCOME_NO_AUTORETRY", "review")
    blockers = sum(x["severity"] == "blocker" for x in issues)
    return {
        "status": "block" if blockers else ("review" if issues else "pass"),
        "transfer_count": len(data["transfers"]),
        "blocker_count": blockers,
        "review_count": len(issues) - blockers,
        "findings": issues,
        "scope": "offline_trace_only_no_provider_calls",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("trace_json", type=Path)
    a = parser.parse_args()
    try:
        if a.trace_json.stat().st_size > 5_000_000:
            raise ValueError("Fixture exceeds 5 MB")
        result = audit(json.loads(a.trace_json.read_text(encoding="utf-8")))
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(json.dumps({"status": "error", "error_type": type(exc).__name__}))
        return 2
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["status"] == "pass" else 2


if __name__ == "__main__":
    raise SystemExit(main())
