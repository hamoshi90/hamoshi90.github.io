# Transaction audit reference

Input: synthetic/redacted JSON containing `transfers[]`. Each transfer has a unique `idempotency_key`, `events` containing `status`, `send_attempts`, optional `receipt_verified` and `debited`. Do not use actual wallet addresses, phone numbers, OTPs or tokens. The script reports **indices and categorical problem codes only**, never identifiers.

```json
{"transfers":[{"idempotency_key":"synthetic-op-001","events":[{"status":"created"},{"status":"previewed"},{"status":"submitted"},{"status":"pending"},{"status":"succeeded"}],"send_attempts":1,"receipt_verified":true,"debited":true}]}
```

- Failure matrix: preview succeeds but confirmation rejects; pending after request timeout; provider accepts but client times out; duplicate confirm taps; wrong recipient/account owner; duplicate webhooks; restart while pending; balance unchanged after rejection; historical records stale.
- For an unresolved operation, isolate its business ID only in authorized internal environment, inspect evidence without resending, then reconcile against both provider status and local ledger. Unknown != failed.
- App-specific result codes MUST be interpreted per endpoint and provider version. A native-app success fixture does not automatically authorize an undocumented production API integration.
- The script's findings are heuristics based on sanitized trace records; never infer that any actual account balance changed.
