---
name: financial-transaction-safety
description: Audit wallet send/receive flows, idempotency, ambiguous transfer outcomes, rejected transactions, balance reconciliation and finance regressions for authorized apps. Use when the user mentions a payment, transfer, wallet balance, 2FA confirmation followed by financial action, duplicated send, receipt, refund, reconciliation or provider result codes. Work with synthetic/sanitized traces and avoid real transfers by default.
---

# Financial Transaction Safety

Perform financial-transaction reviews using an evidence-first, **no-live-transfer** workflow. This skill complements Project Dev Guardian and Superpowers; it does not operate a wallet or authorize financial actions.

## Procedure
1. Establish the exact project and its approved baseline; treat unrelated customer projects as **independent projects**. Never import their production secrets, sessions, or account data into another project.
2. Reproduce a bug with sanitized traces in an isolated mock/staging context. Distinguish network/HTTP status from endpoint-specific application result and from verified ledger finality.
3. Model state transitions: created -> previewed -> submitted -> pending -> succeeded/rejected; allow `unknown` when outcome cannot be determined. Never reinterpret timeout or HTTP 200 alone as successful or rejected transfer.
4. Require a stable server-generated idempotency key for each logical operation; prove the same logical operation cannot settle twice after retries, restarts or concurrency. An **unknown** transfer must be reconciled by non-mutating status/ledger checks, not blindly resent.
5. Check atomic balance updates, durable outbox/inbox references, duplicate callback protection, per-user ownership, audit trails without sensitive values, and consistency under network interruption.
6. For a sanitized trace JSON, run `python scripts/financial_audit.py /path/to/trace.json`; investigate all blockers and review flags. The script verifies ONLY supplied trace states; it cannot prove remote provider settlement.
7. Design regression tests for duplicate submissions, concurrency, partial failure, 2FA expiry, request timeout, eventual success, rejected receipt, and server restart. Separate observed evidence, hypothesized causes, and tests not performed.
8. Stop before any real transfer or production permission change; request specific authorization and use a controlled environment with explicit limits. Never print bearer tokens, encrypted request bodies, OTPs, personal wallet addresses, passwords or private IDs.

## Output
Report: baseline; evidence examined; definitive state; invariant violations; blocked vs review findings; minimal risk fix; mock test results; live/production steps requiring approval. Never claim fund movement without independent provider/ledger evidence.

See [Transaction audit reference](references/transaction-audit.md) for fixture format and failure matrix.
