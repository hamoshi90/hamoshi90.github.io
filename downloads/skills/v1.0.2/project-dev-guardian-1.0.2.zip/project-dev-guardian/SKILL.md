---
name: project-dev-guardian
description: Reusable engineering workflow for analyzing, testing and safely evolving a source-code project from an uploaded ZIP/folder or connected GitHub repository. Use when the user asks to inspect project code, find bugs or security weaknesses, plan a feature, preserve a release baseline, validate a package, review a PR, or prepare a release candidate. Keeps unrelated projects and their credentials isolated; performs no live financial operations.
---

# Project Dev Guardian

Work on one project at a time. Prefer the user's already-provided source and existing approval boundaries. Use source evidence instead of assuming a known baseline is still current.

## 1. Establish the exact source and safe scope

1. Identify the target project, approved baseline, test/deployment status, and desired outcome from the current conversation, project metadata, repository or uploaded archive.
2. Confirm actual access. GitHub connection alone does not imply access to any of the user's repositories. Never treat a public open-source tooling repository as the user's application source.
3. Prefer GitHub connected tools for repository reading, diffs, CI and PRs, and use read-only inspection before code changes. For uploaded source archives, work in a scratch copy. Keep SHA-256 manifests when useful.
4. Separate source, credentials, payment records, sessions and test environments across projects. Never transplant secrets, account tokens, cookies, encryption keys or customer records between projects.
5. Keep the last approved baseline unchanged. Place proposed fixes in a candidate branch/package unless the user explicitly approves updating the baseline. Do not conflate 'prepared candidate' with 'deployed'.

## 2. Plan before editing (Spec Kit-inspired)

Write a short `spec`: problem, observed behavior, expected behavior, constraints, prohibited side effects. Then define acceptance cases and a small ordered task list. For a bug, start with a minimal reproducer when available. Do not invent requirements or integration details absent from evidence.

## 3. Preflight static inspection

Execute `scripts/preflight.py` against a local source folder or ZIP in a compatible Python environment. It is read-only and requires no third-party Python modules:

```bash
python scripts/preflight.py /path/to/project.zip --output /path/to/report.json
python scripts/preflight.py /path/to/source
```

This checks ZIP path traversal/symlinks, Python syntax, JSON syntax, candidate embedded secrets (without printing values), and selected risky-code patterns. It is an inexpensive first-pass heuristic, **not** a substitute for Semgrep, Gitleaks, dependency CVE analysis, unit/integration tests, or expert security review. Do not mark a project production-ready on a preflight pass alone. Do not run any bundled executable from an untrusted archive.

## 4. Deep analysis as available

Read `references/tooling.md` for capabilities and prerequisites. Use the strongest **actually available** tools, with strict distinction between connected tools and tools merely described in GitHub repositories:

- GitHub: inspect files, issues, PR changes, actions, release branches and CI using the authenticated connector and its actual access.
- Documentation: obtain version-matched official references; use Context7 when installed, or official documentation/browser sources otherwise.
- Semgrep + Gitleaks: run code-pattern and secret scans only in suitable local/CI environments with those binaries actually installed. Redact findings.
- Schemathesis: test the API contract on a controlled mock/staging target. Do not direct generated traffic at a live financial API.
- Playwright: run UI smoke/regression tests against isolated test accounts and controlled browsers.
- Serena: optionally assist precise edits when semantic tooling is available and connected.
- Repomix: optionally prepare a context export after excluding secrets and sensitive files; verify its output before uploading to chat.
- Superpowers/OpenAI Skills: apply appropriate reusable workflows only when available; a repository link is not an installation.

## 5. Implement conservatively

Preserve established interfaces, database migration history and backwards compatibility unless the requested change explicitly supersedes them. Handle money as integer minor units or decimal types as applicable. Treat idempotency and transfer retry behavior as safety-critical. Never interpret an HTTP 200 response alone as a successful financial transaction; evaluate API-specific application codes and reconcile results. A log of a transaction is not an authorization to make a new live transaction.

## 6. Test and report

Run locally feasible checks; state which tests were actually executed. Prefer deterministic unit tests and mocked external systems. Do not enable unrestricted production permissions, real deposits/withdrawals, unreviewed secret access, live transfers, or public deployment as part of an inspection step.

Use the compact reporting pattern in `references/report-template.md`: inspected source, baseline/status, findings by severity with paths and evidence, actions taken, tests with pass/fail/blocked, unverified areas, and a safe next step. Clearly distinguish confirmed findings from heuristic suspicions.

## Tool status discipline

A CLI being listed in the reference does not mean it is installed; a ChatGPT app being suggested does not mean it is connected; and a Skill ZIP being generated does not mean it is installed. Verify each condition before claiming activation or execution.
