#!/usr/bin/env python3
"""Read-only source preflight for a directory or ZIP; no third-party packages."""
import argparse
import ast
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import sys
import zipfile

EXCLUDE = {'.git', '.venv', 'venv', 'node_modules', '__pycache__', 'dist', 'build', '.next', '.pytest_cache'}
MAX_FILE = 2 * 1024 * 1024
MAX_ENTRIES = 30000
MAX_ZIP_UNCOMPRESSED = 1024 * 1024 * 1024
SENSITIVE_NAMES = {'.env', '.env.local', '.env.production', 'id_rsa', 'id_ed25519', 'credentials.json'}
KEY_RE = re.compile(r"(?im)^\s*[\w-]*(?:api[_-]?key|secret[_-]?key|client[_-]?secret|password|access[_-]?token|private[_-]?key)[\w-]*\s*[:=]\s*['\"][^'\"\n]{6,}['\"]")
RISK_RE = [
    ('dynamic_execution', re.compile(r'\b(?:eval|exec)\s*\(')),
    ('shell_true', re.compile(r'\bshell\s*=\s*True\b')),
    ('verify_false', re.compile(r'\bverify\s*=\s*False\b')),
]


def include_name(name):
    p = PurePosixPath(str(name).replace('\\', '/'))
    return not any(part in EXCLUDE for part in p.parts)


def suspicious_name(name):
    p = PurePosixPath(name)
    return p.name.lower() in SENSITIVE_NAMES or p.suffix.lower() in {'.pem', '.p12', '.pfx', '.key'}


def check_bytes(name, raw, findings):
    if suspicious_name(name):
        findings.append(dict(severity='warning', rule='sensitive_file_present', path=name, line=None,
                             message='Sensitive-looking file path; contents were not inspected.'))
        return
    if len(raw) > MAX_FILE or b'\x00' in raw[:4096]:
        return
    suffix = PurePosixPath(name).suffix.lower()
    if suffix not in {'.py', '.json', '.js', '.jsx', '.ts', '.tsx', '.yaml', '.yml', '.toml', '.sh', '.ini', '.cfg'}:
        return
    try:
        text = raw.decode('utf-8-sig')
    except UnicodeDecodeError:
        return
    if suffix == '.py':
        try:
            ast.parse(text, filename=name)
        except SyntaxError as e:
            findings.append(dict(severity='error', rule='python_syntax', path=name, line=e.lineno,
                                 message='Python syntax error: ' + (e.msg or 'invalid syntax')))
    if suffix == '.json':
        try:
            json.loads(text)
        except json.JSONDecodeError as e:
            findings.append(dict(severity='error', rule='json_syntax', path=name, line=e.lineno,
                                 message='JSON syntax error: ' + e.msg))
    for lineno, line in enumerate(text.splitlines(), 1):
        if KEY_RE.search(line):
            findings.append(dict(severity='warning', rule='possible_embedded_secret', path=name,
                                 line=lineno, message='Possible hard-coded credential; value redacted.'))
        if suffix in {'.py', '.sh', '.js', '.jsx', '.ts', '.tsx'}:
            for rule, pattern in RISK_RE:
                if pattern.search(line):
                    findings.append(dict(severity='warning', rule=rule, path=name, line=lineno,
                                         message='Review potentially unsafe code pattern in context.'))


def scan_folder(root, findings):
    count = 0
    for base, dirs, files in os.walk(root, followlinks=False):
        dirs[:] = sorted(d for d in dirs if d not in EXCLUDE and not (Path(base) / d).is_symlink())
        for fn in sorted(files):
            path = Path(base) / fn
            rel = path.relative_to(root).as_posix()
            if not include_name(rel):
                continue
            count += 1
            if count > MAX_ENTRIES:
                findings.append(dict(severity='error', rule='too_many_entries', path='', line=None,
                                     message='Entry count limit exceeded.'))
                return count
            if path.is_symlink():
                findings.append(dict(severity='warning', rule='symlink_skipped', path=rel, line=None,
                                     message='Symlink was not followed.'))
                continue
            if suspicious_name(rel):
                check_bytes(rel, b'', findings)
                continue
            try:
                if path.stat().st_size <= MAX_FILE:
                    check_bytes(rel, path.read_bytes(), findings)
            except (OSError, PermissionError) as e:
                findings.append(dict(severity='warning', rule='read_error', path=rel, line=None,
                                     message='Cannot read file: ' + type(e).__name__))
    return count


def scan_zip(zip_path, findings):
    count = 0
    seen = set()
    try:
        with zipfile.ZipFile(zip_path) as z:
            infos = z.infolist()
            if len(infos) > MAX_ENTRIES:
                findings.append(dict(severity='error', rule='too_many_entries', path='', line=None,
                                     message='ZIP entry count limit exceeded.'))
                return len(infos)
            if sum(i.file_size for i in infos) > MAX_ZIP_UNCOMPRESSED:
                findings.append(dict(severity='error', rule='zip_too_large', path='', line=None,
                                     message='Uncompressed size exceeds safety limit.'))
                return len(infos)
            for info in infos:
                original = info.filename
                normalized = original.replace('\\', '/')
                p = PurePosixPath(normalized)
                if original.startswith(('/', '\\')) or '..' in p.parts or re.match(r'^[A-Za-z]:', original):
                    findings.append(dict(severity='error', rule='unsafe_zip_path', path=original,
                                         line=None, message='Potential path traversal or absolute path.'))
                    continue
                if info.is_dir() or not include_name(normalized):
                    continue
                if normalized in seen:
                    findings.append(dict(severity='warning', rule='duplicate_zip_entry', path=normalized,
                                         line=None, message='Duplicate ZIP member name.'))
                seen.add(normalized)
                if stat.S_ISLNK((info.external_attr >> 16) & 0xFFFF):
                    findings.append(dict(severity='warning', rule='zip_symlink', path=normalized,
                                         line=None, message='ZIP symlink not followed.'))
                    continue
                count += 1
                if suspicious_name(normalized):
                    check_bytes(normalized, b'', findings)
                    continue
                if info.file_size > MAX_FILE:
                    continue
                if info.compress_size > 0 and info.file_size > 5 * 1024 * 1024 and info.file_size / info.compress_size > 200:
                    findings.append(dict(severity='warning', rule='compression_ratio', path=normalized,
                                         line=None, message='Suspiciously high compression ratio.'))
                    continue
                try:
                    with z.open(info) as f:
                        raw = f.read(MAX_FILE + 1)
                    if len(raw) <= MAX_FILE:
                        check_bytes(normalized, raw, findings)
                except (OSError, RuntimeError, zipfile.BadZipFile) as e:
                    findings.append(dict(severity='warning', rule='zip_read_error', path=normalized,
                                         line=None, message='Cannot read member: ' + type(e).__name__))
    except (OSError, zipfile.BadZipFile) as e:
        findings.append(dict(severity='error', rule='zip_open_error', path=str(zip_path), line=None,
                             message='Cannot open ZIP: ' + type(e).__name__))
    return count


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', help='Source directory or .zip archive')
    parser.add_argument('--output', help='Optional output JSON path; never writes inside source automatically')
    args = parser.parse_args()
    source = Path(args.source)
    findings = []
    if source.is_dir():
        kind = 'directory'
        count = scan_folder(source, findings)
    elif source.is_file() and zipfile.is_zipfile(source):
        kind = 'zip'
        count = scan_zip(source, findings)
    else:
        parser.error('Source must be an accessible directory or ZIP archive')
    findings.sort(key=lambda f: (f.get('path', ''), f.get('line') or 0, f['rule']))
    report = {'source': str(source), 'kind': kind, 'files_seen': count, 'errors': sum(f['severity'] == 'error' for f in findings),
              'warnings': sum(f['severity'] == 'warning' for f in findings), 'findings': findings,
              'limitations': ['Heuristic, read-only preflight. No third-party scanner, dependency analysis, runtime tests or live API tests performed.',
                              'Sensitive-looking files were not opened.']}
    encoded = json.dumps(report, indent=2, ensure_ascii=False)
    if args.output:
        dst = Path(args.output)
        if dst.resolve() == source.resolve():
            parser.error('Report must not overwrite the source')
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_text(encoded + '\n', encoding='utf-8')
    print(encoded)
    return 2 if report['errors'] else 0


if __name__ == '__main__':
    sys.exit(main())
