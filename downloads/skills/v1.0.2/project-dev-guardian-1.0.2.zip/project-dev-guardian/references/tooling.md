# Open-source tooling map

These are upstream project URLs, not evidence of installation. Check current upstream instructions and project license before installing or embedding. Pin versions and review supply-chain integrity in production environments.

| Tool | Upstream | Purpose | Requirements / safe-use notes |
|---|---|---|---|
| GitHub MCP Server | https://github.com/github/github-mcp-server | GitHub interactions | Use an existing ChatGPT GitHub connector when available; additional MCP hosting may be unnecessary. Scope repository permissions. |
| Spec Kit | https://github.com/github/spec-kit | Requirements-to-implementation workflow | Specification steps can be followed manually within chat. Do not require its CLI if unavailable. |
| OpenAI Skills | https://github.com/openai/skills | Reusable instructions and assets | Imported skills require explicit setup. Follow each license and setup. |
| Repomix | https://github.com/yamadashy/repomix | Codebase-to-context packaging | Exclude .env, tokens, private keys, credentials, databases and build output; inspect generated output. |
| Context7 | https://github.com/upstash/context7 | Current library docs | Requires an installed/connected app or supported MCP server. |
| Serena | https://github.com/oraios/serena | Semantic code navigation/editing | Requires a language-server-aware environment and compatible MCP client. |
| Playwright MCP | https://github.com/microsoft/playwright-mcp | Browser automation | Requires a running, connected browser/MCP setup; target a test deployment. |
| Semgrep | https://github.com/semgrep/semgrep | Static code pattern analysis | Requires installed CLI or CI. Some rules/services use network; check configuration. |
| Gitleaks | https://github.com/gitleaks/gitleaks | Secret scanning | Requires installed binary or CI. Redact results and avoid exporting secrets. |
| Schemathesis | https://github.com/schemathesis/schemathesis | OpenAPI/property-based testing | Requires controlled API/test target. Disable or mock write/transfer operations. |
| Superpowers | https://github.com/obra/superpowers | Disciplined planning, TDD, debugging | Requires skill/plugin setup for automated workflows. |

## Read-only quick audit

1. Read repository/archive metadata and the project's declared baseline.
2. Run the included `scripts/preflight.py` in a scratch environment.
3. Review reported paths/lines and distinguish possible secrets or dangerous patterns from confirmed vulnerabilities.
4. If external tooling exists, run version-pinned scans with non-production test fixtures. Never feed private source files or credentials into third-party remote services without explicit authorization.
5. Run unit tests, contract tests and staging UI tests. Preserve logs with secrets removed.
6. Deliver results and mark remaining risks as unverified, not passed.
