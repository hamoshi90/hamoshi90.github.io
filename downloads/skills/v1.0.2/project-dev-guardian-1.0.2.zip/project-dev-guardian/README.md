# project-dev-guardian — standalone skill 1.0.2

project-dev-guardian is a standalone skill extracted without code changes from Ali Mohammad's Project Dev Guardian v1.0.2 source release. The included Python scripts are optional and do not provide a hosted service, live finance access, or deployment. See README and LICENSE.

Publisher: Ali Mohammad (علي محمد).
Source suite: Project Dev Guardian v1.0.2.
Source bundle SHA-256: `982095e4c382f65ecff8cce1dcfe606df2304aaf24935388d3015960fb912bca`.
Website: https://hamoshi90.github.io/tools/project-dev-guardian/
Support: https://hamoshi90.github.io/support/

Contains one SKILL.md plus related optional resources. Upload as a single skill only if your ChatGPT account and workspace support skill uploads. Alternatively review the text and scripts locally. Uploading a ZIP does not imply an official OpenAI Plugin Directory listing or security certification.

License: Apache License 2.0 for first-party material the publisher is authorized to license. Check NOTICE.
