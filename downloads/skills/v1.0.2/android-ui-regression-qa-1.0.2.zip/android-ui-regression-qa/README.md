# android-ui-regression-qa — standalone skill 1.0.2

android-ui-regression-qa is a standalone skill extracted without code changes from Ali Mohammad's Engineering Quality Suite v1.0.2 source release. The included Python scripts are optional and do not provide a hosted service, live finance access, or deployment. See README and LICENSE.

Publisher: Ali Mohammad (علي محمد).
Source suite: Engineering Quality Suite v1.0.2.
Source bundle SHA-256: `b34d23025a5e9fc080547cc963be4aced83178f6a1684b724b088ea331b61b83`.
Website: https://hamoshi90.github.io/tools/engineering-quality-suite/
Support: https://hamoshi90.github.io/support/

Contains one SKILL.md plus related optional resources. Upload as a single skill only if your ChatGPT account and workspace support skill uploads. Alternatively review the text and scripts locally. Uploading a ZIP does not imply an official OpenAI Plugin Directory listing or security certification.

License: Apache License 2.0 for first-party material the publisher is authorized to license. Check NOTICE.
